import { createStore } from 'vuex'

export default createStore({
  state: {
    // 用于新闻详情区
    isDetails: false,
    // 用于新闻id进入详情
    newsId: 0,
  },
  mutations: {
    // 用于评论区 暂未开放
    increment(state, val) {
      this.state.isDetails = val;
    },
    incrementId(state, val) {
      this.state.newsId = val;
    }
  },
  actions: {
  },
  modules: {
  }
})
