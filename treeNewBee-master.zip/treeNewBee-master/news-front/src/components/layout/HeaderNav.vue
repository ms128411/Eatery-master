<!--丁世强-->
<!--后台头部-->
<template>
  <div class="nav-box">
    <div style="color: white;font-size: 30px;">新闻发布管理系统</div>
    <div class="right-container">
      <div>欢迎你: </div>

<!--      用户下拉框-->
      <el-dropdown>
        <span style="color: white;font-size: 16px;">
          管理员<i class="el-icon-arrow-down el-icon--right"></i>
        </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="logoutUser">退出</el-dropdown-item>
            </el-dropdown-menu>
          </template>
      </el-dropdown>

<!--      主题色-->
      <el-dropdown>
        <span class="el-dropdown-link" style="font-size: 20px;">
          <i class="el-icon-s-opportunity"></i>
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="handleColor('c1')">蓝色</el-dropdown-item>
            <el-dropdown-item @click="handleColor('c2')">绿色</el-dropdown-item>
            <el-dropdown-item @click="handleColor('c3')">红色</el-dropdown-item>
            <el-dropdown-item @click="handleColor('c4')">黄色</el-dropdown-item>
            <el-dropdown-item @click="handleColor('c5')">橙色</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
export default {
  name: "HeaderNav",
  methods:{
    // 处理主题颜色
    handleColor(color){
      this.$emit('colorChange', color);
    },
    // 退出登陆
    logoutUser(){
      this.$confirm('确认退出吗? ', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(()=>{
        this.$router.replace('/login.html');
      }).catch(()=>{
        this.$message({
          type: 'info',
          message: '取消退出'
        })
      })
    }
  }
}
</script>

<style scoped>

/*整个页头盒子*/
.nav-box{
  display: flex;
  align-items: center;
  justify-content: space-between;

  width: 100%;
  height: 100%;
  background-color: #000000;
}
/*右边部分*/
.right-container{
  display:  flex;
  align-items: center;
  color: white;
}
/*元素间的间隙*/
.right-container *{
  margin: 10px;
}
</style>
