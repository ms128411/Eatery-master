<!--丁世强-->
<!--侧栏菜单-->
<template>
  <!-- 菜单栏 -->
  <el-menu :collapse="isCollapse" :collapse-transition="false" router :default-active="$route.path">
    <!--菜单项-->
    <el-submenu index="/01">
      <template #title>
        <i class="el-icon-user-solid"></i>
        <span>用户管理</span>
      </template>
      <!-- 菜单子项 -->
      <el-menu-item index="/user-list.html" @click="addUserList">
        <span>用户列表</span>
      </el-menu-item>
    </el-submenu>
    <!--菜单项-->
    <el-submenu index="/02">
      <template #title>
        <i class="el-icon-postcard"></i>
        <span>新闻列表</span>
      </template>
      <!-- 菜单子项 -->
      <el-menu-item index="news-list.html" @click="addNewsList">
        <span>新闻列表</span>
      </el-menu-item>
    </el-submenu>
    <!--菜单收起项-->
    <el-menu-item v-if="isCollapse == false" @click="changeCollapse('1')">
      <i class="el-icon-caret-left"></i><span>收起</span>
    </el-menu-item>
    <el-menu-item v-if="isCollapse == true" @click="changeCollapse('2')">
      <i class="el-icon-caret-right"></i><span>展开</span>
    </el-menu-item>
  </el-menu>
</template>

<script>
export default {
  name: "Menu",
  data:()=>({
    // 关闭导航栏
    isCollapse : false,
  }),
  methods:{
    // 向父组件传值 用于在主页显示切换标签卡 显示用户列表
    addUserList(){
      this.$emit('addUserList', '用户列表');
    },
    // 向父组件传值 用于在主页显示切换标签卡 显示用户列表
    addNewsList(){
      this.$emit('addNewsList', '新闻列表');
    },
    // 向父组件传值 用于在主页显示切换标签卡 是否展开菜单
    changeCollapse(commend){
      if(commend == '1'){
        this.isCollapse = true;
      }
      if(commend == '2'){
        this.isCollapse = false;
      }
      this.$emit('changeCollapse', this.isCollapse);
    },
  },
}
</script>

<style scoped>
/*菜单元素*/
.el-menu{
  height: 100%;
}
</style>
