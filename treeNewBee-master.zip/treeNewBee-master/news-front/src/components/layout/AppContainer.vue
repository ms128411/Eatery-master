<!--后台整体布局-->
<template>
  <el-container style="width: 100%;height: 100%;">
    <el-header style="width: 100%;padding: 0;" >
      <!-- :style="'background: red'" -->
      <header-nav @colorChange="colorChange" :style="bgColorValueC"></header-nav>
    </el-header>
    <el-container>
      <!--菜单行-->
      <el-aside style="height: 100%;" :style="isCollapse ? 'width: 50px' : ''">
        <Menu @addUserList="addUserList" @changeCollapse="changeCollapse" @addNewsList="addNewsList"></Menu>
      </el-aside>
      <!--:style="'background: red'"-->
      <el-main :style="bgColorValueC">
        <!--主页选项卡-->
        <el-tabs v-model="tabId" type="card" closable @tab-remove="removeTab">
          <el-tab-pane v-for="iter in menuList" :label="iter" :name="iter" :key="iter" >
            <div v-if="iter == '我的桌面'">
              <desktop></desktop>
            </div>
            <!--添加切换选项-->
            <user-list v-else-if="iter == '用户列表'"></user-list>
            <news-list v-else-if="iter == '新闻列表'" @addComment="addComment" @commentDataId="commentDataId"></news-list>
            <comment v-else-if="iter == '评论管理'" :comment_data_id="comment_data_id"></comment>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Menu from "@/components/layout/Menu";
import UserList from "@/views/user/UserList";
import NewsList from "@/views/news/NewsList";
import Desktop from "@/views/main/Desktop";
import HeaderNav from "./HeaderNav";
import Comment from "../../views/news/Comment";
export default {
  name: "AppContainer",
  components: {Comment, HeaderNav, Desktop, NewsList, UserList, Menu},
  computed:{
    bgColorValueC(){
      return `background: ${this.bgColorValue}`;
    }
  },
  data:()=>({
    // 主题颜色值
    bgColorValue: '',
    // 主题颜色
    bgColor:{
      c1: '',
      c2: '#144a74',
      c3: '#d8d5ec',
      c4: '#eea2a4',
      c5: 'rgb(125, 84, 99)',
    },
    // 向评论区传递的id
    comment_data_id: '',
    // 主页功能切换卡标签内容
    menuList: ['我的桌面'],
    // 选项卡选择
    tabId : "我的桌面",
    // 是否展开
    isCollapse : false,
  }),
  methods:{
    // 颜色处理
    colorChange(color){
      this.bgColorValue = this.bgColor[color];
    },
    // 监听是否折叠
    changeCollapse(isCollapse){
      this.isCollapse = isCollapse;
    },
    // 检查标签选项卡是否存在
    isExist(listName){
      let result = false;
      this.menuList.forEach(name=>{
        if(name == listName){
          result = true;
        }
      });
      return result;
    },
    // 添加页面选项卡
    addUserList(listName){
      if(!this.isExist(listName)){
        this.menuList.push(listName);
      }
      // 切换选项卡功能
      this.tabId = "用户列表";
    },
    // 添加评论页面选项卡
    addComment(listName){
      if(!this.isExist(listName)){
        this.menuList.push(listName);
      }
      // 切换选项卡功能
      this.tabId = listName;
    },
    // 向评论组件传递id
    commentDataId(id){
      this.comment_data_id = id;
    },
    // 添加页面选项卡
    addNewsList(listName){
      if(!this.isExist(listName)){
        this.menuList.push(listName);
      }
      // 切换选项卡功能
      this.tabId = "新闻列表";
    },
    // 选择删除标签卡
    removeTab(name){
      if(name == '我的桌面'){
        return ;
      }
      // 获取删除的标签卡索引
      let nameIndex = this.menuList.findIndex(mn=> mn == name);
      // 删除标签卡
      this.menuList.splice(nameIndex, 1);
      // 定位到上一个标签
      this.tabId = this.menuList[this.menuList.length-1];
    }
  },
}
</script>

<style scoped>

</style>
