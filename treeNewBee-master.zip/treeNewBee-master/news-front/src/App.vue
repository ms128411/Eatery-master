<template>
  <router-view></router-view>
</template>

<style lang="scss">
html, body{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#app {
  height: 100%;
}

</style>
