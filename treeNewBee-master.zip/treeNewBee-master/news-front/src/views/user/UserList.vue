<template>
  <!--作者：柴聪-->
  <!--  功能 用户列表-->
  <el-card>
    <!--操作区域-->
    <el-card class="headerSet">
      <template #header>
        <!--新增用户-->
        <el-row>
          <el-col :span="3">
            <el-button @click="drawer=true" type="primary" round><i class="el-icon-plus" @calick="addUser"></i>新增用户</el-button>
          </el-col>
          <!-- 刷新-->
          <!--        <el-col :span="3">-->
          <!--          <el-button type="primary" round @click="refrech"><i class="el-icon-plus" ></i>刷新</el-button>-->
          <!--        </el-col>-->
          <!--查询-->
          <el-col :span="6" :offset="10">
            <el-form inline style="display:block;">
              <el-input v-model="selectUser.name" class="select"  placeholder="请输入账户"></el-input>
              <el-button type="primary"  @click="selectusername"><i class="el-icon-search"></i></el-button>
            </el-form>
          </el-col>
        </el-row>
      </template>
      <!--    数据展示区域-->

      <el-table :data="Users" border style="width: 100%">
        <el-table-column prop="id" label="编号" width="180px"></el-table-column>
        <el-table-column prop="userName" label="用户名" width="180px"></el-table-column>
        <el-table-column prop="phone" label="手机号" width="180px"></el-table-column>
        <el-table-column prop="realName" label="真实名" width="180px"></el-table-column>
        <el-table-column prop="email" label="邮箱" width="180px"></el-table-column>
        <el-table-column prop="" label="操作" width="200px">
          <template #default="{row}">
            <el-row>
              <el-col :span="3" :offset="6">
                <!--            数据设置-->
                <el-button size="small" type="success" circle @click="dataSet(row);updateUser=true"><i class="el-icon-s-tools"></i></el-button>
                <!--    用户信息更改处-->

              </el-col>
              <el-col :span="3" :offset="6">
                <!--            数据删除-->
                <el-button size="small" type="danger" circle @click="dataRemove(row)"><i class="el-icon-delete-solid"></i></el-button>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
      </el-table>

      <!--    数据修改抽屉区-->
      <el-drawer title="用户信息更改"
                 v-model="updateUser"
                 :with-header="false">
        <!--      数据添加组件-->
        <div>
          <div class="" style="height: 150px"> </div>
          <el-form >
            <el-input class="openSet" placeholder="用户账户" v-model="updateUserdata.userName"> </el-input>
            <el-input class="openSet" placeholder="用户手机号" v-model="updateUserdata.phone"> </el-input>
            <el-input class="openSet" placeholder="用户真实姓名" v-model="updateUserdata.realName"> </el-input>
            <el-input class="openSet" placeholder="邮箱" v-model="updateUserdata.email"> </el-input>
            <el-row :gutter="0">
              <el-col :span="12" :offset="5">
                <el-button align="center" style="width: 100%;margin-top: 25px;" type="primary" round @click="updataUserSubmit(row)">确认修改账户</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </el-drawer>


      <!--    分页区-->
      <el-pagination

          background
          layout="prev, pager, next"
          :total=number
          @current-change="paging"
          current-page="currentPage"
          page-size="10">
      </el-pagination>
      <!--    添加账户的抽屉-->
      <el-drawer title="新账户添加"
                 v-model="drawer"
                 :with-header="false">
        <!--      数据添加组件-->
        <add-user-data @remove="removeMt">
        </add-user-data>
      </el-drawer>
    </el-card>

  </el-card>

</template>

<script>

import AddUserData from "@/views/user/module/AddUserData";
export default {
  name: "UserList",
  components: {AddUserData},
  //数据
  data:()=>({
    // 当前在第几页
    currentPage:1,
    // 删除数据的请求
    removeData:{
      id:-1,
      pageIndex:-1,
      pageSize:10
    },
    number:9,//记录一个默认的有10条数据
    // 分页请求数据
    pagingDataGetRequest:{

      pageIndex:1,  //当前页数
      pageSize:10,  //每一页展示的数据条数
    },
    // 抽屉的关闭
    drawer:false,
    updateUser:false,

    // 要修改的账户信息
    updateUserdata:{
      id:"1",
      userName:"0",
      phone:"0",
      name:"0",
      mail:"0"
    },

    // 数据展示的数据
    Users:[
      {
        id:"1",
        userName:"z哈",
        phone:"是",
        name:"1",
        mail:"发"
      },
      {
        id:"2",
        userName:"方法",
        phone:"啊",
        name:"是的",
        mail:"的"
      }],
    //查询发送的数据
    selectUser:{
      name:"",
      pageIndex:1,
      pagSize:10
    },
    re: false,
  }),

  created() {
    this.refrech();
  },
  //方法区
  methods: {
    //分页跳转事件
    paging(e) {
      this.pagingDataGetRequest.name=this.selectUser.name;
      this.pagingDataGetRequest.pageIndex = e;    //分页页码
      this.pagingDataGetRequest.pageSize = 10;   //每一页数据条数

      console.log(this.pagingDataGetRequest)
      this.axios.get("/customerList", {params: this.pagingDataGetRequest}).then(data => {
        //console.log(data.data.rows);
        this.number = data.data.total
        console.log(this.number)
        console.log("++++++++++++++++++++++++++++++++++++++++++++++")
        console.log(data.data.rows);
        this.Users = data.data.rows;
      }).catch(error => {
        console.log(error)
      })
    },
    // 默认第一页展示数据刷新
    refrech() {

      this.axios.get("/customerList", {params: 0}).then(display => {
        console.log(display.data.rows);
        this.Users = display.data.rows;
        // console.log(display);
        this.number = display.data.total
      });
    },
    // 搜索用户信息
    selectusername() {
      this.selectUser.pageIndex = 1;
      this.selectUser.pagSize = 10;

      this.axios.get("/customerList", {params: this.selectUser}).then(display => {
        this.currentPage=1;
        this.number=display.data.total;
        console.log(display)
        console.log(this.selectUser.name)
        this.Users = display.data.rows;
      })
    },
    // 新增
    addUsers() {

    },
    // 数据设置
    dataSet(user) {
      this.updateUserdata.id=user.id;
      this.updateUserdata.userName=user.userName;
      this.updateUserdata.phone=user.phone;
      this.updateUserdata.realName=user.realName;
      this.updateUserdata.email=user.email;
    },
    // 数据删除样式处理
    dataRemove(row) {

      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 判断是否删除成功
        this.remove(row.id)
        if(this.re){
          console.log("6666666666666666")
          this.refrech();
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }else {
          this.$message({
            type: 'info',
            message: '删除失败!'
          });
        }
      }).catch(() => {
        // alert("有问题")
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },
    //数据删除数据处理
    remove(id){
      // 组装请求数据
      this.removeData.id=id
      this.removeData.pageIndex=this.pagingDataGetRequest.pageIndex;
      this.removeData.pageSize=10;
      //发送请求
      this.axios.get("/customer/remove",
          {params: this.removeData
          }).then(removeinfometion=>{
        console.log("********************")
        console.log(removeinfometion)

        console.log("********************")
        if(removeinfometion.message=="用户删除成功"){
          console.log(removeinfometion.message)
          this.Users=removeinfometion.data.rows;
          this.re=true;
        }else{
          this.re=false;
        }

      }).catch((error)=>{
        console.log(error)
        this.re=false;
      })
    },
    //确认修改账户
    updataUserSubmit(userdata){
      console.log(userdata)
      //console.log("12345648497asdf sadf asdf asd fadg aga")
      this.axios.post("/customer/Update",this.updateUserdata).then(message=>{
        console.log("--------------------------------------")
        console.log(message)
        console.log("--------------------------------------")
        if(message.message=="修改成功"){
          userdata=this.updateUserdata;
          this.$message({
            type: 'success',
            message: '修改成功!'
          });
          console.log("修改成功")
        }else{
          this.$message({
            type: 'info',
            message: '修改失败'
          });
          console.log("修改失败")
        }
        console.log(userdata);
      })
    },
    removeMt(e){
      console.log(e);
      this.drawer=e;
    }
  },

}
</script>

<style scoped>
.openSet{
  width: 80%;
  padding-left: 70px;
  margin-top: 25px;
}
div{
  width: 100%;
}
.select{
  width: 200px;
}
.headerSet{
  list-style-type: none;
  display: block;
}


</style>
