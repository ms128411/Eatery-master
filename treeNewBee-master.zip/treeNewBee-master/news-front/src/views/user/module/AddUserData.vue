<template>

  <div>
    <div style="height: 150px"> </div>
    <el-form>
      <el-input class="inputstyle" placeholder="用户账户" v-model="addUser.userName"> </el-input>
      <el-input class="inputstyle" placeholder="用户密码" v-model="addUser.passWord"> </el-input>
      <el-input class="inputstyle" placeholder="用户手机号" v-model="addUser.phone"> </el-input>
      <el-input class="inputstyle" placeholder="用户真实姓名" v-model="addUser.name"> </el-input>
      <el-input class="inputstyle" placeholder="邮箱" v-model="addUser.mail"> </el-input>

      <el-row :gutter="0">
        <el-col :span="12" :offset="5">
          <el-button  align="center" style="width: 100%;margin-top: 25px;" type="primary" round @click="submit">确认新增账户</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import {ElMessage} from "element-plus";

export default {
  name: "AddUserData",
  data:()=>({
    addUser:{
      userName:"",
      passWord:"",
      phone:"",
      name:"",
      mail:""
    },
    // Users:[
    //   {
    //     id:"1",
    //     userName:"z哈",
    //     phone:"是",
    //     name:"1",
    //     mail:"发"
    //   },
    //   {
    //     id:"2",
    //     userName:"方法",
    //     phone:"啊",
    //     name:"是的",
    //     mail:"的"
    //   }]
  }),
  methods:{
    //新增用户
    submit(){
      this.axios.post("/customer/new",this.addUser).then(statu=>{

        if (statu.status==200){  //判断是否成功
          // statu.message
          this.$emit('remove',false);
          console.log(statu)
          ElMessage({
            message: `添加成功${statu.message}`,
            type: 'success'
          });
          this.addUser="";
        }
        //this.Users=statu.data.rows;
        // this.$emit("addUser",this.Users)
        console.log(statu.status);
      }).catch(error=>{
        this.addUser.userName="";
        console.log(error)
      })
      this.$emit('colose')
    }
  }
}
</script>

<style scoped>
.inputstyle{
  width: 60%;
  padding-left: 70px;
  margin-top: 25px;
}
div{
  width: 100%;
}
</style>