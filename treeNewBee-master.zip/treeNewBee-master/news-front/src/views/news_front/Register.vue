<!--用户注册 周宏-->
<template>
  <div class="all d-flex align-items-center justify-content-center">
    <div class="body d-flex justify-content-between shadow-only-bottom" style="border-radius: 10px">
      <!--    LEFT-->
      <form class="col p-5 mb-4 mx-3" id="registerForm" style="width: 350px;">
        <span class="mb-3 textColor textSize">Join us</span>
        <div class="form-group mt-4 position-relative">
          <label class="text-black-50">账&nbsp;号</label>
          <span class="bi bi-person icon-fill"></span>
          <input v-model="registerUser.userName" type="text" class="form-control lineInput" placeholder="admin">
        </div>
        <div class="form-group mt-4 position-relative">
          <label class="text-black-50">密&nbsp;码</label>
          <span class="bi bi-lock icon-fill"></span>
          <input v-model="registerUser.passWord" type="password" class="form-control lineInput" placeholder="••••••••">
        </div>
        <div class="form-group mt-4 position-relative">
          <label class="text-black-50">手&nbsp;机</label>
          <span class="bi bi-phone icon-fill"></span>
          <input v-model="registerUser.phone" type="text" class="form-control lineInput" placeholder="10086">
        </div>
        <div class="form-group mt-4 position-relative">
          <label class="text-black-50">姓&nbsp;名</label>
          <span class="bi bi-people icon-fill"></span>
          <input v-model="registerUser.realName" type="text" class="form-control lineInput" placeholder="奥巴马">
        </div>
        <div class="form-group mt-4 position-relative">
          <label class="text-black-50">邮&nbsp;箱</label>
          <span class="bi bi-envelope icon-fill"></span>
          <input v-model="registerUser.email" type="text" class="form-control lineInput" placeholder="Super@Svip.com">
        </div>
      </form>
      <!--    RIGHT-->
      <div class="d-flex align-items-center justify-content-center">
        <div>
          <button type="button" class="btn btn-info btn-circle text-white" @click="register">Next&emsp;<i class="bi bi-arrow-right"></i></button>
          <div class="mt-3 px-2 d-flex justify-content-between textColor">
            <a href="/home.html">用户手册</a>
            <a href="/user-login.html" class="a1">登录</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {ElMessage} from "element-plus";

export default {
  el: '#registerForm',
  name: "Register",
  data: () => ({
    registerUser: {
      userName: '',
      passWord: '',
      phone: '',
      realName: '',
      email: ''
    },
    errorList: []
  }),
  methods: {
    register () {
      if (this.validate()) {
        this.axios.post('/register', this.registerUser).then(result => {
          // 登陆成功
          if(result.code == '00000') {
            ElMessage.success({
              message: '注册成功!',
              type: 'success'
            });
            // 验证成功跳转到主页
            setTimeout(() => {
              this.$router.push('/user-login.html');
            },2000);
          } else{
            // 失败提示
            ElMessage.error("该账户已存在!");
          }
        }).catch(() => {
          // 失败提示
          ElMessage.error("网络错误!");
        })
      }
    },
    validate () {
      this.errorList = []
      if (this.registerUser.userName == '') {
        this.errorList.push('请输入账号');
      } else {
        let reg = /^[a-zA-Z][a-zA-Z0-9_]{4,15}$/;
        if (!reg.test(this.registerUser.userName)) {
          this.errorList.push('字母开头，允许5-16字节，允许字母数字下划线');
        }
      }
      if (this.registerUser.passWord == '') {
        this.errorList.push('请输入密码');
      } else {
        if (this.registerUser.passWord.length < 5) {
          this.errorList.push('密码长度不得少于5位');
        }
      }
      if (this.registerUser.email == '') {
        this.errorList.push('请输入邮箱');
      } else {
        let reg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if (!reg.test(this.registerUser.email)) {
          this.errorList.push('请输入正确的邮箱');
        }
      }
      let reg = this.errorList.join(', ');
      if(reg){
        ElMessage.error(reg);
      }
      return this.errorList.length <= 0;
    }
  }
}
</script>

<style scoped>
.all{
  margin: 0 auto;
  height: 100%;
  width: 100%;
  background-color: #d8d5ec;
}
.body{
  background-color: white;
}

/*阴影*/
.shadow-only-bottom{
  box-shadow: 0px 14px 14px -12px #5E5E5E;
}

/*文字*/
.textColor{
  color: #498bc4;
}
.textSize{
  font-size: 30px;
}

/*按钮*/
.btn-info{
  background-color: #498bc4;
  margin-right: 36px;
}
/*椭圆*/
.btn-circle {
  width: 150px;
  height: 46px;
  text-align: center;
  padding: 6px 0;
  font-size: 15px;
  /*line-height: 1.428571429;*/
  border-radius: 24px;
  border-color: #498bc4;
}
/*边框*/
.btn:focus,.btn:active:focus,
.btn.active:focus,.btn.focus,
.btn:active.focus,.btn.active.focus {
  outline: none;
  border-color: rgb(3, 138, 253);
  /*border-color: transparent;*/
  box-shadow:none;
}

/*登录*/
.a1{
  text-decoration: none;
  color: #498bc4;
  position: relative;
  left: -35px;
}
a{
  text-decoration: none;
  color: #498bc4;
  position: relative;
}
a:hover{
  color: #6201ff;
}

/*图标*/
.icon-fill{
  position: absolute;
  top: 49%;
  left: 0;
}

/*输入框*/
.lineInput{
  border:none;
  border-bottom:1px solid #9a9a9a;
  padding-left: 27px;
  padding-right: 0;
  outline: none;
}
input::-webkit-input-placeholder {
  /* WebKit browsers */
  color: #000000;
}
input:-moz-placeholder {
  /* Mozilla Firefox 4 to 18 */
  color: #000000;
}
input::-moz-placeholder {
  /* Mozilla Firefox 19+ */
  color: #000000;
}
input:-ms-input-placeholder {
  /* Internet Explorer 10+ */
  color: #000000;
}
</style>
