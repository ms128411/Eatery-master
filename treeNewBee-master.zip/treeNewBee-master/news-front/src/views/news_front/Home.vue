<!--新闻首页 丁世强-->
<template>
  <div>
    <!--页面头-->
    <div class="header bg-dark">
      <ul class="nav nav-pills">
        <li class="nav-item" @click="handleActive('home')">
          <a class="nav-link" :class="{active: activeState.home}" href="#" @dblclick="handleDbClick">首页</a>
        </li>
        <li class="nav-item" @click="handleActive('currentAffairs')">
          <a class="nav-link" href="#" :class="{active: activeState.currentAffairs}">时政</a>
        </li>
        <li class="nav-item" @click="handleActive('society')">
          <a class="nav-link" href="#" :class="{active: activeState.society}">社会</a>
        </li>
        <li class="nav-item" @click="handleActive('internationality')">
          <a class="nav-link" href="#" :class="{active: activeState.internationality}">国际</a>
        </li>
        <li class="nav-item" @click="handleActive('military')">
          <a class="nav-link" href="#" :class="{active: activeState.military}">军事</a>
        </li>
        <li class="nav-item" @click="handleActive('policeLaw')">
          <a class="nav-link" href="#" :class="{active: activeState.policeLaw}">警法</a>
        </li>
        <li class="nav-item" @click="handleActive('hotNews')">
          <a class="nav-link" href="#" :class="{active: activeState.hotNews}">热点新闻</a>
        </li>
        <li class="nav-item">
          <input class="form-control" type="search" placeholder="搜索新闻" v-model="keywordTitle">
        </li>
        <li>
          <button class="btn btn-outline-success" @click="search">Search</button>
        </li>
      </ul>
    </div>
    <!--页面主体-->
    <div class="main mt-4">
      <!--新闻列表-->
      <home-news :keyword="keywordTitle" v-show="activeState.home" @selectHome="selectHome"></home-news>
      <current-affairs v-show="activeState.currentAffairs"></current-affairs>
      <society v-show="activeState.society"></society>
      <internationality v-show="activeState.internationality"></internationality>
      <military v-show="activeState.military"></military>
      <hot-news v-show="activeState.hotNews"></hot-news>
      <police-law v-show="activeState.policeLaw"></police-law>
      <new-details v-if="sss == true"></new-details>
    </div>
    <!--页脚-->
    <div class="footer d-flex justify-content-center align-items-center" >
      <span style="color: #d0d0d0;">Copyright © 2018-2019 新闻发布中心</span>
    </div>
  </div>
</template>

<script>
import CurrentAffairs from "./home_component/CurrentAffairs";
import Society from "./home_component/Society";
import Internationality from "./home_component/Internationality";
import Military from "./home_component/Military";
import HotNews from "./home_component/HotNews";
import PoliceLaw from "./home_component/PoliceLaw";
import HomeNews from "./home_component/HomeNews";
import {mapState} from 'vuex'
import NewDetails from "@/views/news_front/home_component/NewDetails";
export default {
  name: "Home",
  components: {NewDetails, HomeNews, PoliceLaw, HotNews, Military, Internationality, Society, CurrentAffairs},
  // 生命周期创建前
  created() {
    // 默认首页
    this.activeState.home = true;
  },
  data:()=>({
    // 决定了页面是否显示
    activeState: {
      home: false,
      currentAffairs: false,
      society: false,
      internationality: false,
      military: false,
      hotNews:false,
      policeLaw: false,
    },
    // 用户标题搜索
    keywordTitle: '',
  }),
  // 用于新闻详情
  computed:{
    ...mapState({
      sss:'isDetails'
    })
  },
  // 用于评论区
  watch:{
    // 是否展示新闻详情
    sss(value,old){
      console.log(value);
      console.log(old);
      if(value == true){
        for(let iter in this.activeState){
          this.activeState[iter] = false;
        }
      }else{
        // this.activeState.home = true;
      }
    },
    // 对象监听
    // 'activeState.home'() {
    //   if (this.activeState.home == true) {
    //     this.$store.commit('increment', false);
    //   }
    // },
    // 深度监听
    deep: true,
  },

  methods:{
    handleDbClick(){
      this.$store.commit('increment', false);
    },
    // 当搜索时显示主页
    selectHome(){
      this.activeState.home = true;
      // 遍历重新赋值
      for(let iter in this.activeState){
        if(iter == 'home'){
          continue;
        }
        else{
          this.activeState[iter] = false;
        }
      }
    },
    // 搜索事件
    search(){
      // this.keywordTitle
    },
    // 处理页面跳转切换
    handleActive(name){
      // 激活当前选项
      this.activeState[name] = !this.activeState[name];

      // 验证是否是自身
      if(this.activeState[name] == false){
        let tempState = false;
        // 查看除了自身还有没有被选中的
        for(let iter in this.activeState) {
          if (iter == name) {
            continue;
          }
          if(this.activeState[iter] == true){
            tempState = true;
          }
        }
        // 如果没有 取消无效
        if(tempState != true){
          this.activeState[name] = true;
        }
      }
      // 遍历重新赋值
      for(let iter in this.activeState){
        if(iter == name){
          continue;
        }
        else{
          this.activeState[iter] = false;
        }
      }
      // 关闭评论区
      this.$store.commit('increment', false);
    }
  },
}
</script>

<style scoped>
.main{
  margin: 0 auto;

  width: 90%;
  height: auto;
}

.footer{
  width: 100%;
  height: 60px;
  background-color: #333;
}

.nav-pills li{

}
</style>
