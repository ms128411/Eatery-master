<!--用户登陆 丁世强 / 周宏-->
<template>
  <div class="all d-flex align-items-center justify-content-center">
    <div class="body d-flex justify-content-center shadow-only-bottom shadow-only-light" style="border-radius: 10px">
      <div class="offset-2 d-flex align-items-center">
        <form class="col p-5" id="loginForm" style="width: 300px;">
          <div class="mb-3 textColor d-flex justify-content-center"><h4>树&nbsp;新&nbsp;风&nbsp;新&nbsp;闻&nbsp;系&nbsp;统</h4></div>
          <div class="mb-0 textColor d-flex justify-content-center"><h4>登&nbsp;陆&nbsp;界&nbsp;面</h4></div>
          <div class="form-group mt-4 position-relative">
            <label class="text-black-50">账&nbsp;号</label>
            <span class="bi bi-person icon-fill"></span>
            <input v-model="loginUser.userName" type="text" class="form-control lineInput" placeholder="admin">
          </div>
          <div class="form-group mt-4 position-relative">
            <label class="text-black-50">密&nbsp;码</label>
            <span class="bi bi-lock icon-fill"></span>
            <input v-model="loginUser.passWord" type="password" class="form-control lineInput" placeholder="••••••••">
          </div>
          <div class="form-group d-flex justify-content-center mt-5">
            <button type="button" class="form-control btn btn-info btn-circle text-white" @click="login">登&emsp;陆</button>
          </div>
        </form>
      </div>
      <div class="body change p-0 shadow-only-right" style="border-radius: 15px">
        <img src="../../assets/login_front/oneCover.png" class="shadow-only-bottom" style="border-radius: 15px;height: 100%;" @click="goRegister">
      </div>
    </div>
  </div>
</template>

<script>
import {ElMessage} from "element-plus";

export default {
  el: '#loginForm',
  name: "Login",
  data:() => ({
    loginUser: {
      userName: '',
      passWord: '',
    },
    errorList: []
  }),
  methods: {
    // 跳转注册
    goRegister(){
      setTimeout(()=>{
        this.$router.push('/register.html');
      }, 500);
    },
    // 登陆
    login () {
      if (this.validate()) {
        this.axios.post('/front/login', this.loginUser).then(result => {
          // 登陆成功
          if(result.code == null) {
            ElMessage.success({
              message: '登陆成功!',
              type: 'success'
            });
            // 验证成功跳转到主页
            setTimeout(() => {
              this.$router.push('/home.html');
            },2000)
          } else{
            // 失败提示
            ElMessage.error("账号或密码错误!");
          }
        }).catch(() => {
          // 失败提示
          ElMessage.error("网络错误!");
        });
      }
    },
    validate () {
      this.errorList = []
      if (this.loginUser.userName == '') {
        this.errorList.push('请输入账号');
      } else {
        let reg = /^[a-zA-Z][a-zA-Z0-9_]{4,15}$/;
        if (!reg.test(this.loginUser.userName)) {
          this.errorList.push('字母开头，允许5-16字节，允许字母数字下划线');
        }
      }
      if (this.loginUser.passWord == '') {
        this.errorList.push('请输入密码');
      } else {
        if (this.loginUser.passWord.length < 5) {
          this.errorList.push('密码长度不得少于5位');
        }
      }
      let reg = this.errorList.join(', ');
      if (reg){
        ElMessage.error(reg)
      }
      return this.errorList.length <= 0;
    },
  },
}
</script>

<style scoped>
.all{
  margin: 0 auto;
  height: 100%;
  width: 100%;
  background-color: #d8d5ec;
}
.top{
  min-height: 15%;
}
.body{
  background-color: white;
}

.footer{
  min-height: 15%;
}
.loginImage{
  /*background-image: url("src/assets/login_front/oneCover.png");*/
  background-image: url("../../assets/login_front/oneCover.png");
}
/*阴影*/
.shadow-only-bottom{
  box-shadow: 0px 20px 20px -22px #5E5E5E;
}
.shadow-only-right{
  box-shadow: 20px 0px 20px -22px #5E5E5E;
}
.shadow-only-light{
  box-shadow: -20px 20px 20px -22px #5E5E5E;
}
/*图像跳转特效*/
.change:hover{
  transform: scale(1.01, 1.01);
  box-shadow: 0 0 12px #5E5E5E;
}
.change{
  transition: 0.7s;
}
/*文字*/
.textColor{
  color: #498bc4;
}

/*按钮*/
.btn-info{
  background-color: #498bc4;
}
/*椭圆*/
.btn-circle {
  width: 140px;
  height: 32px;
  text-align: center;
  padding: 6px 0;
  font-size: 12px;
  /*line-height: 1.428571429;*/
  border-radius: 16px;
  border-color: #498bc4;
}
/*边框*/
.btn:focus,.btn:active:focus,
.btn.active:focus,.btn.focus,
.btn:active.focus,.btn.active.focus {
  outline: none;
  border-color: rgb(3, 138, 253);
  /*border-color: transparent;*/
  box-shadow:none;
}

/*图标*/
.icon-fill{
  position: absolute;
  top: 49%;
  left: 0;
}

/*输入框*/
.lineInput{
  border:none;
  border-bottom:1px solid #9a9a9a;
  padding-left: 27px;
  padding-right: 0;
  outline: none;
}
input::-webkit-input-placeholder {
  /* WebKit browsers */
  color: #000000;
}
input:-moz-placeholder {
  /* Mozilla Firefox 4 to 18 */
  color: #000000;
}
input::-moz-placeholder {
  /* Mozilla Firefox 19+ */
  color: #000000;
}
input:-ms-input-placeholder {
  /* Internet Explorer 10+ */
  color: #000000;
}
</style>
