<template>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb ">
        <i class="bi bi-house-fill"></i>
        <li class="breadcrumb-item"><a href="#">首页</a></li>
        <li class="breadcrumb-item"><a href="#">时政</a></li>
        <li class="breadcrumb-item active" aria-current="page">详情</li>
      </ol>
    </nav>
    <!--卡牌内容区域-->
    <div class="card" style="width: 50rem;">
      <div class="card-body">
        <h4 class="card-title" style="font-weight: bolder">{{news.newsTitle}}</h4>
        <h6 class="card-subtitle mb-2 text-muted" style="font-size: small">
          <i class="bi bi-person-fill"></i>管理员&nbsp; 2021-7-28 11:10:00&nbsp; <i class="bi bi-eye"></i>24
          <button>收藏</button>
        </h6>
        <hr/>
        <p class="card-text" v-html="news.newsContent"></p>
      </div>
    </div>
</template>

<script>
import {mapState} from "vuex";

export default {
  name: "NewDetails",
  data:()=>({
    news: {
      newsContent: '',
      newsTitle: '',
    }
  }),
  // 数据详情id
  computed:{
    ...mapState({
      id:'newsId',
    })
  },
  // 监听变化
  watch:{
    id(value,old){
      console.log(value, 'new id');
      console.log(old, 'new id');
      this.axios.get('/newsContent', {
        params:{
          id: value
        }
      }).then(result=>{
        console.log(result);
        this.news.newsContent = result.data.content;
        this.news.newsTitle = result.data.title;
      })
    },
  },
  created() {
    this.axios.get('/newsContent', {
      params:{
        id: this.id
      }
    }).then(result=>{
      console.log(result);
      this.news.newsContent = result.data.content;
      this.news.newsTitle = result.data.title;
    })
  }
}
</script>

<style scoped>

</style>
