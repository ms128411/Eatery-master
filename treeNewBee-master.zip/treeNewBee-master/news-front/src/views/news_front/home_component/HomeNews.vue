<!--新闻首页 丁世强-->
<template>
  <div v-if="keyword == ''">
    <!--各大板块的数据项-->
    <div class="card mb-4" v-for="(iter, index) in homeData" :key="iter">
      <div class="card-header d-flex justify-content-between">
        <div>
          <i class="bi bi-house"></i> &nbsp;
          <span class="fw-bold">{{nesType[index]}}</span>
        </div>
        <div>
          <a class="fw-bold" style="text-decoration: none;color: fuchsia;">更多</a>
        </div>
      </div>
      <div class="card-body p-0" v-for="iter2 in iter[Object.keys(iter)[0]]" :key="iter2">
        <ul>
          <li class="d-flex justify-content-between mr-2">
            <a style="text-decoration: none;color: #676666;" href="#" @click="detailsJump(iter2.id)">
              <i class="bi bi-brush"></i>{{iter2.title}}
            </a>
            <span style="margin-right: 10px;">{{iter2.createTime}}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <new-details v-else-if="sss"></new-details>
  <div v-else>
    <el-card style="width: 65%">
      <el-row :gutter="20" >
        <el-col :span="22" :offset="1">
          <el-card style="width:100%;margin-top: 20px" v-for="iter in responseInformation" :key="iter" @click="detailsJump(iter.id)">
            <!--卡片的主题部分-->
            <div>
              <b>{{ iter.title }}</b><br><!--新闻的标题-->
            </div>
            <div style="margin-top:10px">
              <i class="el-icon-user-solid"></i>&nbsp; 111&nbsp;&nbsp;&nbsp;
              <i class="el-icon-time"></i> &nbsp;222&nbsp;&nbsp;&nbsp;
              <i class="el-icon-view"></i> &nbsp;333&nbsp;&nbsp;&nbsp;
            </div>
          </el-card>
        </el-col>
      </el-row>
      <!--    使用布局-->
      <el-row :gutter="20" style="margin-top: 20px">
        <el-col :span="18" :offset="1">
          <!--        分页区域-->
          <el-pagination background
                         layout="prev,pager,next"
                         :total=page.dataTotalNumber
                         @current-change="pageJump"
          >
          </el-pagination>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
import NewDetails from "./NewDetails";
export default {
  name: "HomeNews",
  components: {NewDetails},
  props : ['keyword'],
  // 监听器
  watch:{
    // 监听用户搜索值的变化进行数据的刷新
    keyword(){
      // 查询数据
      this.axios.post('/newsList', {
        title: this.keyword
      }).then(result=>{
        console.log(result);
        this.responseInformation = result.data.rows;
        this.page.dataTotalNumber = result.data.total;
      })

      // 告诉父组件用户在搜索
      this.$emit('selectHome');
      this.$store.commit('increment', false);
    }
  },
  // 声明周期创建时
  created() {
    // 查询每个板块的一部分数据
    // 查询时政 current_affairs
    this.selectAllData(0, 'current_affairs');
    // 查询社会 society
    this.selectAllData(1, 'society');
    // 查询国际 internationality
    this.selectAllData(2, 'internationality');
    // 查询军事 military
    this.selectAllData(3, 'military');
    // 查询警法 police_law
    this.selectAllData(4, 'police_law');
    // 查询热点新闻 hot_news
    this.selectAllData(5, 'hot_news');

    console.log(this.homeData);
  },
  data:()=>({
    // 搜索分页数据
    page:{
      dataTotalNumber: 0,
    },
    // 页面数据
    homeData: [],
    // 新闻分类
    nesType: {
      0: '时政资讯',
      1: '社会新闻',
      2: '国际新闻',
      3: '军事新闻',
      4: '警法新闻',
      5: '热点新闻',
    },
    // 搜索数据
    responseInformation:[{
      "id": 2698,
      "title": "广西北部湾海洋生态与环境保护实验室在桂林挂牌成立",
      "type": 1,
      "djs": 5,
      "publicTime": "2018-04-15",
      "zz": "中国新闻网站"
    }]
  }),
  methods:{
    // 跳转详情
    detailsJump(id){
      this.$store.commit('incrementId', id);
      this.$store.commit('increment', true);
    },
    // 页面跳转
    pageJump(curr){
      // 查询数据
      this.axios.post('/newsList', {
        title: this.keyword,
        pageIndex: curr
      }).then(result=>{
        console.log(result);
        this.responseInformation = result.data.rows;
        this.page.dataTotalNumber = result.data.total;
      })
    },
    // 查询主页数据
    selectAllData(type, key){
      this.axios.get('/news/list.do', {
        params: {
          type: type,
        }
      }).then(result=>{
        let tempObj = {};
        tempObj[key] = result.data.rows.slice(0, 8);
        this.homeData.push(tempObj);
      })
    }
  },
}
</script>

<style scoped>
ul li {
  margin: 0;
  padding: 0;
}
a:hover {
  color: hotpink!important;
}
</style>
