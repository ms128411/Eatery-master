<!--热点新闻-->
<!--作用：展示热点新闻内容-->
<!--作者：周威-->
<!--时间：2021年7月28日13点52分-->
<template >
  <div class="row">
  <div class="col-2"></div>
  <div  class="col-6 ">
    <!--面包屑导航-->
    <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 15PX">
      <el-breadcrumb-item :to="{ path: '/home.html' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>热点新闻</el-breadcrumb-item>
    </el-breadcrumb>
    <!--内容列表-->
    <div v-for="row in newsList.rows" :key="row" style="margin-bottom: 15px;" >
      <el-descriptions :title="row.title" column="1" size="small" @click="skip(row.id)"  style="padding-bottom: 6px; border-bottom: 1px solid #aaa7a7">
        <el-descriptions-item label="" style="margin-right: auto">原标题：{{row.introduction}}</el-descriptions-item>
        <el-descriptions-item label="">
          <template #label>
            <i class="el-icon-user"></i>
            {{row.zz}}
            <i class="el-icon-timer"></i>
            {{row.createTime}}
            <i class="bi-eye"></i>
            {{row.djs}}
          </template>
        </el-descriptions-item>
      </el-descriptions>
    </div>
    <!--分页条-->
    <el-pagination layout="total,sizes,prev,pager,next,jumper"
                   :current-page="newsList.pageIndex" :page-size="newsList.pageSize"
                   :total="newsList.total"
                   @current-change="selectCurrentPage"
                   @size-change="pageNumber">
    </el-pagination>
  </div>
  <!--  最新新闻展示页面-->
  <div class="col-4" style="margin-top: 20px">
    <!--<el-affix :offset="120">-->
      <el-card>
        <el-table :data="newest" size="medium " @row-click="skipa">
          <el-table-column label="最新文章" prop="title"></el-table-column>
        </el-table>
      </el-card>
    <!--</el-affix>-->
  </div>
  </div>
</template>

<script>
export default {
  name: "HotNews",
  data:()=>({
    id:5,
    /*新闻列表展示的假数据*/
    newsList: {pageIndex:1},
  //  最新文章假数据
    newest:[]
  }),
  methods:{
    //分页数据请求
    selectAll(){
      this.axios.get('/news/list.do',{params:{pageIndex:this.newsList.pageIndex,pageSize:this.newsList.pageSize,type:this.id}}).then(
          data=>{
            // console.log(data);
            this.newsList = data.data;
          }
      )
    },
    skipAxios(){
      this.axios.get('/newsNew',{params: {type: this.id}}).then(
          data=>{
            console.log(data,"-------------------------------------------------------------------------------------");
            this.newest = data.data;
          }
      )
    },
    //跳转详情
    detailsJump(id){
      this.$store.commit('incrementId', id);
      this.$store.commit('increment', true);
    },
    //分页方法
    pageNumber(pageSize){
      this.newsList.pageSize = pageSize;
      this.selectAll()
    },
    selectCurrentPage(pageIndex){
      console.log(pageIndex ,"-------------------");
      this.newsList.pageIndex = pageIndex;
      console.log(pageIndex);
      this.selectAll();
    },
    //进入内容
    skip(id){
      this.detailsJump(id)
    },
    //获取最新新闻数据
    skipa(row){
      let id = row.id
      this.$store.commit('incrementId', id);
      this.$store.commit('increment', true);
    }
  },
  /*在组件创建前执行下列方法*/
  created(){
    this.selectAll();
    this.skipAxios();
  },
}
</script>

<style scoped>
::v-deep .el-descriptions__header{
  margin-bottom: 0!important;
}
.el-descriptions:hover ::v-deep .el-descriptions__header{
  color: red;
}
::v-deep .el-descriptions__header:hover{
  cursor:pointer;
}
::v-deep .el-descriptions__title:active{
  color:#4790ed;
}
::v-deep .el-table .el-table__body-wrapper .el-table__body  tbody tr td:hover{
  color:#4790ed;
}
</style>


