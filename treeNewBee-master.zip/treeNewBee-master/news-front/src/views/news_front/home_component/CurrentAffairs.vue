<!--时政-->

<!--作者:柴聪-->
<!--上传时间 2021-7-28  15：20-->
<template>

<!-- 新闻区的背景卡片-->
  <el-card style="width: 100%;margin-bottom: 30px" >  <!--创建背景的卡片---->
<!--    新闻区-->
    <el-row :gutter="20">        <!--开启父类型布局---->

<!--      热度新闻区域-->
      <el-col :span="15">             <!--创建一个占有15份的块---->
        <el-row :gutter="20"  v-for="row in responseInformation" :key="row"> <!--创建子类型布局----->
          <el-col :span="22" :offset="1">                                    <!--在子类型布局中创建一个占有22份的块-->

              <el-card class="ch-card" style="width:100%;margin-top: 20px" @click="detailsComment(row.id)" >
                <!--          卡片的主题部分-->
                <el-link :underline="false" href="#">
                  <div style="width: 200%; text-align: left">
                    <div>
                      <p style="font-weight: 600">{{row.title}}</p> <!--新闻的标题-->
                    </div>
                    <div style="margin-top:5px">
                      {{row.introduction}}    <!---新闻的内容---->
                    </div>
                    <div style="margin-top:10px">
                      <i class="el-icon-user-solid"></i>&nbsp; {{row.zz}}&nbsp;&nbsp;&nbsp;
                      <i class="el-icon-time"></i> &nbsp;{{row.createTime}}&nbsp;&nbsp;&nbsp;
                      <i class="el-icon-view"></i> &nbsp;{{row.djs}}&nbsp;&nbsp;&nbsp;
                    </div>
                  </div>
                </el-link>
              </el-card>

          </el-col>
        </el-row>
      </el-col>

<!--      最新新闻区域-->
      <el-col :span="8" :offset="0">
        <el-card style="margin-left:1px;margin-top:25px;width:100%;height: auto;">
          <div>
            <h4 style="margin-bottom: 15px;margin-top: 5px">最新新闻</h4>
          </div>
          <div class="newJournalismModules" v-for=" data in responseNewInformation" :key="data">
            <el-link :underline="false" href="#">

              <div style="width: 100%">

              </div>
              <div @click="newJournalismbBreak(data.id)">{{data.title}}</div>
            </el-link>
            <hr style="margin-top:10px;margin-bottom: 9px">
          </div>
        </el-card>

      </el-col>

    </el-row>
<!--    分页区域     使用布局-->
    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="18" :offset="1">
<!--        分页区域-->
          <el-pagination background
            layout="prev,pager,next"
            :total=dataTotalNumber
             @current-change="pageJump"
          >

          </el-pagination>
      </el-col>
    </el-row>
  </el-card>


</template>

<script>
export default {
  name: "CurrentAffairs",
  data:()=>({
    //数据总条数
    dataTotalNumber:10,

    //获取新闻数据的请求
    requestMessage:{
      type:-1,  //新闻的类型，首页无请求参数，时政到热点新闻对应type属性0到5
      pageIndex:1  //首页无此项，页面下标用于分页
    },

    //用于展示在页面的数据对象      服务端响应过来的数据
    responseInformation:[{
        id:"1",
        title:"郭德纲唱戏",
        type:"军事",
        djs:"12",   //点击率
        publicTime:"2020-12-12", //时间
        introduction:"话说那刘罗锅，从小机灵古怪，嘿，今碰见那邻村的纲子，",
        zz:"刘德华",
        pageIndex:"1",
        pageSize:"10",
        total:"120",
      },{
        id:"2",
        title:"刘罗锅戏演皇帝",
        type:"23",
        djs:"12-",
        publicTime:"123",
        zz:"123",
        pageIndex:"123",
        pageSize:"-12-",
        total:"123",
      }],

    //用于展示最新的新闻数据对象     服务端响应过来的数据
    responseNewInformation:[
      {
          id:1,
          title:"印度在面对心冠疫情前纯粹胡闹，堪称当前世纪的最大笑话"
      },{
          id:2,
          title:"小日本真的是个贱胚子，干净的街道背后不知道有多少藏污纳垢的地方"
      },
      {
        id:3,
        title:"美国的霸权快结束了，因为东方有一雄狮正在苏醒，他就是：中国"
      }
    ]

  }),
  // 本组件创建的时候执行该方法  涉及到vue的声明周期
  created(){
    this.homePageUpload()
    this.homeNewJournalism();
  },


  //方法区域
  methods:{
    //头一次次加载数据
    homePageUpload(){
      this.requestMessage.type=0;  //新闻的类型 1 表示时政
      this.requestMessage.pageIndex=1;  //页数索引位置

      this.axios.get("news/list.do",{params:this.requestMessage}).then((responseContent)=>{
          this.responseInformation=responseContent.data.rows;
          this.dataTotalNumber=responseContent.data.total;
      })
    },

    //单机页码出发的事件
    pageJump(pagenumber){
      //调用换页页面数据刷新的方法
      this.pageChange(pagenumber)
    },
    //单机分页码 跳转
    pageChange(e){
      console.log(e)
      this.requestMessage.type=0;  //新闻的类型 1 表示时政
      this.requestMessage.pageIndex=e;  //页数索引位置
      //发送请求
      this.axios.get("news/list.do",{params:this.requestMessage}).then((responseContent)=>{
        this.responseInformation=responseContent.data.rows;
        this.dataTotalNumber=responseContent.data.total;
      })

    },

    //主页的最新新闻获取
    homeNewJournalism(){
      this.requestMessage.type=0

      this.axios.get("/newsNew",{params:this.requestMessage}).then(data=>{
        console.log(data)
        this.responseNewInformation=data.data;
      }).catch(error=>{
        console.log(error)
      })
    },

    //火热新闻跳转致评论处方法
    detailsComment(id){
      this.$store.commit('incrementId', id);
      this.$store.commit('increment', true);
    },

    //最新新闻跳转至评论处的方法
    newJournalismbBreak(id){
      this.$store.commit('increment',id);
      this.$store.commit('increment',true)
    }
  }

}
</script>

<style scoped>
.ch-card:hover p{
  color: mediumvioletred;
  font-weight: 900 !important;
}
.newJournalismModules:hover div{
  color: black;
  font-weight: 900;
}
</style>
