<!--丁世强-->
<!--主页桌面内容-->
<template>
  <div>主页桌面</div>
</template>

<script>
export default {
  name: "Desktop"
}
</script>

<style scoped>

</style>
