<!--新闻列表 周宏-->
<template>
  <el-form :inline="true" ref="queryForm" :model="queryFormModal" :rules="searchRules">
    <!--  搜索-->
    <el-row justify="end">
      <el-form-item prop="title"><el-input placeholder="输入新闻标题" v-model="queryFormModal.title" size="small" clearable></el-input></el-form-item>
      <el-form-item><el-button type="primary" size="small" @click="handleSearch"><i class="el-icon-search"></i>&nbsp;搜标题</el-button></el-form-item>
    </el-row>
  </el-form>
  <!--  添加-->
  <el-button type="primary" style="width: 100%" size="small" @click="dialogAdd = true"><i class="el-icon-plus"></i>&nbsp;添加</el-button>
  <div style="font-size: 17px;margin: 15px 0;">新闻列表</div>
  <!--  表格-->
  <el-table :data="dataTable.rows" size="small" border stripe>
    <el-table-column align="center" prop="title" label="标题" width="300"></el-table-column>
    <el-table-column align="center" prop="type" label="新闻类型"></el-table-column>
    <el-table-column align="center" prop="djs" label="点击数"></el-table-column>
    <el-table-column align="center" prop="publicTime" label="发表时间" width="250"></el-table-column>
    <el-table-column align="center" prop="zz" label="作者"></el-table-column>
    <el-table-column align="center" label="操作" width="250" fixed="right">
      <template #default="{row}">
        <el-button type="primary" size="mini" @click="openEdit(row)">编辑</el-button>
        <el-button type="danger" size="mini" @click="newsDel(row)">删除</el-button>
        <el-button type="info" size="mini" @click="toComment(row.id)">评论&nbsp;<i class="el-icon-d-arrow-right"></i></el-button>
      </template>
    </el-table-column>
  </el-table>
  <!--    分页-->
  <el-row justify="end" style="margin-top: 15px">
    <el-pagination
      background
      layout="prev, pager, next, total"
      :current-page="dataTable.pageIndex"
      :page-size="dataTable.pageSize"
      :total="dataTable.total"
      @current-change="handleCurrentChange"
    >
    </el-pagination>
  </el-row>
  <!--  修改新闻弹框-->
  <el-dialog
    title="修改新闻"
    v-model="dialogEdit"
    width="30%"
  >
    <el-form ref="updateObj" :model="updateObj">
      <el-form-item label="&emsp;&emsp;标题:" prop="title">
        <el-input disabled v-model="updateObj.title"></el-input>
      </el-form-item>
      <el-form-item label="新闻类型:" prop="type">
        <el-input type="number" v-model="updateObj.type"></el-input>
      </el-form-item>
      <el-form-item label="&emsp;点击量:" prop="djs">
        <el-input disabled v-model="updateObj.djs"></el-input>
      </el-form-item>
      <el-form-item label="&emsp;&emsp;作者:" prop="zz">
        <el-input v-model="updateObj.zz"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
    <span class="dialog-footer">
      <el-button @click="dialogEdit = false">取 消</el-button>
      <el-button type="primary" @click="newsUpdate">确 定</el-button>
    </span>
    </template>
  </el-dialog>
  <!--  新增新闻弹框-->
  <el-dialog
    title="新增新闻"
    v-model="dialogAdd"
    width="30%"
  >
    <el-form ref="dataAddRef" :model="dataAdd" :rules="dataAddRules">
      <el-form-item label="标&emsp;&emsp;题:" prop="title">
        <el-input v-model="dataAdd.title"></el-input>
      </el-form-item>
      <el-form-item label="作&emsp;&emsp;者:" prop="zz">
        <el-input v-model="dataAdd.zz"></el-input>
      </el-form-item>
      <el-form-item label="简&emsp;&emsp;介:" prop="introduction">
        <el-input v-model="dataAdd.introduction"></el-input>
      </el-form-item>
      <el-form-item label="新闻类型:" prop="type">
        <el-input type="number" v-model="dataAdd.type"></el-input>
      </el-form-item>
      <el-form-item label="新闻内容:" prop="content">
        <el-input v-model="dataAdd.content"></el-input>
      </el-form-item>
      <!--      <el-form-item label="发表时间:" v-model="dataTable.publicTime" prop="djs">-->
      <!--        <el-date-picker-->
      <!--            v-model="timeValue"-->
      <!--            type="datetime"-->
      <!--            placeholder="选择日期时间"-->
      <!--            :default-time="defaultTime">-->
      <!--        </el-date-picker>-->
      <!--      </el-form-item>-->
    </el-form>
    <template #footer>
    <span class="dialog-footer">
      <el-button @click="dialogAdd = false">取 消</el-button>
      <el-button type="primary" @click="newsAdd">确 定</el-button>
    </span>
    </template>
  </el-dialog>
</template>

<script>
// import {ElMessage} from "element-plus";

export default {
  name: "NewsList",
  data: () => ({
    // 查询
    queryFormModal: {
      title: '',
      pageIndex: '',
      pageSize: '',
      total: ''
    },
    // 表格数据
    dataTable:{
      rows: [{
        title: '123',
        type: '123',
        djs: '123',
        publicTime: '---',
        zz: '1414'
      }],
      pageIndex:1,
      pageSize: 13,
      total: 456
    },
    // 需改数据
    updateObj: {
      title: '',
      type: '',
      djs: '',
      publicTime: '',
      zz: ''
    },
    // 新增数据
    dataAdd: {
      title: '',
      zz: '',
      introduction: '',
      type: '',
      content: '',
      djs: '',
      publicTime: '',
    },
    // 修改用户弹框是否显示
    dialogEdit: false,
    // 新增用户弹框是否显示
    dialogAdd: false,
    // 记录当前行
    thisRow: {},
    // // 时间绑定值
    // timeValue: '',
    // // 设置默认时间
    // defaultTime: new Date(2000, 1, 1, 12, 0, 0), // '12:00:00'
    // 查询验证
    searchRules: {
      title: [{required: true, message: '不能查询空信息！'}]
    },
    // 添加验证
    dataAddRules: {
      title: [{required: true, message: '不能输入空信息！', trigger: 'blur'}],
      zz: [{required: true, message: '不能输入空信息！', trigger: 'blur'}],
      introduction: [{required: true, message: '不能输入空信息！', trigger: 'blur'}],
      type: [{required: true, message: '不能输入空信息！', trigger: 'blur'}],
      content: [{required: true, message: '不能输入空信息！', trigger: 'blur'}]
    }
  }),
  created() {
    this.upDataNews()
    // 从后端获取页面数据
    // this.axios.post('/newsList', this.queryFormModal).then(result => {this.dataTable = result.data.rows;})
  },
  methods: {
    // 页面数据更新请求
    upDataNews() {
      // 发送ajax进行后端数据查询
      this.axios.post('/newsList', this.queryFormModal).then(result => {this.dataTable = result.data})
    },
    // 跳转评论
    toComment(id) {
      this.$emit('addComment', '评论管理');

      this.$emit('commentDataId', id);
      // this.$router.push('/comment.html');
    },

    // 添加
    newsAdd() {
      this.$refs.dataAddRef.validate((val) => {
        if(!val) {
          return
        }
        // 添加新闻的时间
        this.dataAdd.publicTime = this.getNowFormatDate();
        // 添加新闻的点击数
        this.dataAdd.djs = 0;
        // 将添加的数据渲染到界面表格
        // this.dataTable.rows.push(this.dataAdd);
        // 把添加对数据向后端发送请求
        this.axios.post('/newsAdd', this.dataAdd).then(result => {this.dataTable = result.data;})
        // 关闭
        this.dialogAdd = false;
        // 更新页面数据显示
        this.upDataNews()
        // this.$refs.dataAddRef.resetFields();
        // 清空
        this.dataAdd = {};
      })
    },

    // 删除
    newsDel(row) {
      // 通过row查找索引
      let index = this.dataTable.rows.findIndex(dt => dt.title == row.title);
      this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 删除
        this.dataTable.rows.splice(index, 1);
        // 删除请求
        this.axios.post('/newsDel', row).then(result => {this.dataTable = result.data;})
        this.upDataNews()
        // 提示框
        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },

    // 打开修改框
    openEdit(row) {
      // 打开修改框
      this.dialogEdit = true
      // 获取当前行的数据
      // this.updateObj
      // 把当前行的数据复制到修改框row内，并呈现原数据
      this.updateObj = {...row};
      // 记录当前行数据
      this.thisRow = row;
    },
    // 修改
    newsUpdate() {
      // 将用户编辑的数据渲染到当前行
      let findIndex = this.dataTable.rows.findIndex(dt => dt.title == this.thisRow.title);
      // 查找当前行索引，并把页面的数据替换成用户修改的数据
      this.dataTable[findIndex] = this.updateObj;
      // 向后端提交当前时间
      this.updateObj.publicTime = this.getNowFormatDate();
      // 向后端发送ajax数据
      this.axios.post('/newsUpdata', this.updateObj).then(result => {
        this.dataTable = result.data.rows;
      })
      this.upDataNews()
      // 关闭修改框
      this.dialogEdit = false;
    },

    // 查询
    handleSearch() {
      this.$refs.queryForm.validate((val) => {
        if(!val) {
          return
        }
      })
      // 发送ajax进行后端数据查询
      this.axios.post('/newsList', this.queryFormModal).then(result => {this.dataTable = result.data})
    },

    // 分页
    // 处理页码改变
    handleCurrentChange(pageIndex) {
      // this.axios.post('/newsList', pageIndex).then(result => {this.dataTable = result.data})
      this.queryFormModal.pageIndex = pageIndex;
      this.upDataNews();
    },
    // 处理每页显示的条数改变
    // handleSizeChange(pageSize) {
    //   this.queryFormModal.pageSize = pageSize;
    //   this.queryFormModel.pageIndex = 1;
    //   this.handleSearch();
    // },

    // 获取当前时间
    getNowFormatDate() {
      let date = new Date();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      let hours = date.getHours();
      let minutes = date.getMinutes();
      let seconds = date.getSeconds();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      if (hours >= 0 && hours <= 9) {
        hours = "0" + hours;
      }
      if (minutes >= 0 && minutes <= 9) {
        minutes = "0" + minutes;
      }
      if (seconds >= 0 && seconds <= 9) {
        seconds = "0" + seconds;
      }
      let currentdate = date.getFullYear() + "-" + month + "-" + strDate + " " + hours + ":" + minutes + ":" + seconds;
      return currentdate;
    },

  }
}
</script>

<style scoped>

</style>
