<!--评论管理 周宏-->
<template>
  <el-table :comment_data_id="comment_data_id" :data="dataTable.rows" border stripe size="small">
    <el-table-column align="center" prop="title" label="新闻标题"></el-table-column>
    <el-table-column align="center" prop="content" label="新闻所属类型" width="200"></el-table-column>
    <el-table-column align="center" prop="user" label="评论人" width="200"></el-table-column>
    <el-table-column align="center" label="是否置顶" fixed="right" width="150">
      <template #default="{row}">
        <el-switch v-model="row.zd" active-color="#13ce66" inactive-color="#999999" @click="upDataZd(row)"></el-switch>
      </template>
    </el-table-column>
    <el-table-column align="center" label="操作" fixed="right" width="150">
      <template #default="{row}">
        <el-button type="danger" size="mini" @click="commentDel(row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <!--    分页-->
  <el-row justify="end" style="margin-top: 15px">
    <el-pagination
      background
      layout="prev, pager, next, total"
      :current-page="dataTable.pageIndex"
      :page-size="dataTable.pageSize"
      :total="dataTable.total"
      @current-change="handleCurrentChange"
    >
    </el-pagination>
  </el-row>

</template>

<script>
export default {
  name: "Comment",
  // 绑定父组件从新闻列表传来的id
  props : ['comment_data_id'],
  // 监听事件，切换标签进行页面数据更新
  watch:{
    comment_data_id(){
      this.upDataComment()
    }
  },
  data: () => ({
    // 查询
    queryFormModal: {
      id: '',
      title: '',
      userName: ''
    },
    // 表格数据
    dataTable: {
      rows: [
        {
          id: '',
          title: '1',
          content: '1',
          user: '1',
          zd: '1'
        },
        {
          id: '',
          title: '1',
          content: '1',
          user: '1',
          zd: '0'
        }
      ]
    }
  }),
  created() {
    this.upDataComment()
  },
  methods: {
    // 页面数据更新
    upDataComment() {
      this.axios.get('/newsComment', {params: {id : this.comment_data_id}}).then(result => {
        // 通过map映射的方式将zd的值变为布尔值
        if(result == ""){return;}
        result.data.rows = result.data.rows.map(row => {
          row.zd = row.zd === 1;
          return row;
        });
        this.dataTable = result.data;
      })
    },

    // 删除评论
    commentDel(row) {
      // 通过row查找索引
      let index = this.dataTable.rows.findIndex(dt => dt.id == row.id);
      this.$confirm('此操作将永久删除该评论, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 删除
        this.dataTable.rows.splice(index, 1);
        // 删除axios请求
        console.log(row);
        this.axios.get('/deleteComment', {params: row})
        // 提示框
        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },

    // 修改置顶
    upDataZd(row) {
      // 判断获取到的zd值是0 / 1 ， 并渲染到界面
      row.zd = row.zd ? 1 : 0;
      // 发送请求到数据
      let params = {id: row.id, zd: row.zd};
      this.axios.get('/newsRecommend', {params: params})
      this.upDataComment()
    },

    // 处理页码改变
    handleCurrentChange(pageIndex) {
      this.dataTable.pageIndex = pageIndex;
      this.upDataComment();
    }
  }
}
</script>

<style scoped>

</style>
