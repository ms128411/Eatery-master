<!--丁世强-->
<!--登陆界面-->
<template>
  <div class="login-box">
    <el-card shadow="always">
      <h2>树新风新闻发布系统</h2>

      <!--  登陆框  -->
      <el-form :model="userData" :rules="userDataRules" ref="loginForm">
        <el-form-item prop="userName">
          <el-input clearable placeholder="账号" v-model="userData.userName"></el-input>
        </el-form-item>
        <el-form-item prop="passWord">
          <el-input clearable placeholder="密码" v-model="userData.passWord" type="password"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" style="width: 100%;" @click="jumpIndex">登陆</el-button>
        </el-form-item>
      </el-form>

      <h4>版本: V1.0.0.0</h4>
    </el-card>
  </div>
</template>

<script>
import { ElMessage } from 'element-plus'
import preventBack from 'vue-prevent-browser-back';
export default {
  mixins: [preventBack],   // 注入禁止返回插件
  name: "Login",
  data:()=>({
    // 用户账号登陆数据
    userData:{
      userName: "",
      passWord: ""
    },

    // 账号表单验证
    userDataRules:{
      userName: [
        {
          required: true,
          message: '账号必填'
        }
      ],
      passWord: [
        {
          required: true,
          message: '密码必填'
        }
      ]
    },
  }),
  methods:{
    // 登陆按钮事件
    jumpIndex(){
      this.$refs.loginForm.validate(val=>{
        if(!val){
          return false;
        }
        // 发送ajax请求验证账号密码
        this.axios.post('/login', this.userData).then(result=>{
          // 登陆成功
          if(result.code == "00000"){
            // 验证成功跳转到主页
            this.$router.push('/index.html');
            ElMessage.success({
              message: '登陆成功!',
              type: 'success'
            });
          } else{
            // 失败提示
            ElMessage.error("账号或密码错误!");
          }
        }).catch(()=>{
          // 失败提示
          ElMessage.error("网络错误!");
        });
      });
    }
  },
  computed:{

  },
}
</script>

<style scoped>
/*登陆盒子 控制整个登陆居中*/
.login-box{
  display: flex;
  justify-content: center;
  align-items: center;

  height: 100%;

  background-image: url(../assets/login/login-bg.jpg);
  background-size: cover;
}
/*卡片体*/
.el-card{
  width: 400px;
  text-align: center;
  opacity: 0.6;
  transition: 0.8s;
}
/*卡片鼠标经过样式*/
.el-card:hover{
  transform: scale(1.1, 1.1);
  opacity: 0.9;
}

h2{
  margin-top: 0;
}
</style>
