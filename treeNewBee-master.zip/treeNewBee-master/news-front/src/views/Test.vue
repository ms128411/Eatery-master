<!--丁世强-->
<!--ajax测试模块 不展示-->
<template>
  <div>
    <el-button @click="ajax">测试AJAX访问</el-button>
  </div>

</template>

<script>
export default {
  name: "Test",
  methods:{
    ajax(){
      this.axios.post('/test',{test: 'ABC'}).then(data=>{
        console.log(data);
      });
    }
  }
}
</script>

<style scoped>

</style>
