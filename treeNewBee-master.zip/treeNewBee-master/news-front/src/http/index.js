// 配置axios的封装
// 1. 导入axios模块
import axios from "axios";
import qs from 'qs';
import {ElMessage} from 'element-plus'

// 2. 配置请求的默认设置 todo
// axios.defaults.baseURL = 'http://192.168.113.68:80/';
axios.defaults.baseURL = 'http://192.168.113.175:80/';  // 对接崔超凡
// axios.defaults.baseURL = 'http://192.168.113.6:80/';  // 对接周威
// axios.defaults.baseURL = 'http://192.168.113.9:8080/';  // 对接刘永良
axios.defaults.headers['Content-Type'] = 'application/x-www-form-urlencoded';
// 3. 配置请求的拦截
axios.interceptors.request.use(
    function (config) {
        // 配置对post请求的参数转换
        config.transformRequest = function (data) {
            // 转换参数
            return qs.stringify(data, {indices:false});
        }
        // 配置对get请求的参数转换
        config.paramsSerializer = function (params){
            return qs.stringify(params, {indices: false});
        }
        return config;
    },
    function () {

    }
);
// 4. 配置响应的拦截
axios.interceptors.response.use(
    function (response) {
        // 后端响应数据在 response.data 中 后端响应的格式{status,code,message,data}
        // status:响应的状态。code：响应的逻辑错误编码。message：响应的提示信息。data：响应的数据
        // 获取后端响应的真实数据
        let result = response.data;
        // 判断后端响应的数据
        if (!result.code || result.code == '00000') {
            // 返回数据
            return Promise.resolve(result);
        }
        // 显示错误信息
        ElMessage({
            message: `错误码：${result.code};错误提示：${result.message}`,
            type: 'error'
        });
        // 返回错误原因
        return Promise.reject(response);
    },

    function () {

    }
);

// 5. 导出配置好的 axios对象
export default axios;
