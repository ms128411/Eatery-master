import Mock from 'mockjs'

Mock.mock('http://localhost:80/login', function () {
  return {
    "status":200,
    "code":"00000",
    // "code":"A0000",
    "message":"登录成功！",
    data: {
      "id":1,
      "userName":"admin",
      "passWord":"111111"
    },
    "error":null
  }
});
