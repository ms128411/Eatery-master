import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: "login.html"
  },
  // 后台用户登陆
  {
    path: '/login.html',
    component: ()=>import('../views/Login')
  },
  // 前台用户登陆
  {
    path: '/user-login.html',
    component: ()=>import('../views/news_front/Login')
  },
  // 前台用户注册
  {
    path: '/register.html',
    component: ()=>import('../views/news_front/Register')
  },
  // 前台新闻首页
  {
    path: '/home.html',
    component: ()=>import('../views/news_front/Home')
  },
  // 后台管理系统
  {
    path: '/',
    component: ()=>import('../components/layout/AppContainer'),
    children: [
      {
        path: 'index.html',
        component: ()=>import('../views/Index'),
      },
      {
        path: '/user-list.html',
        component: ()=>import('../views/user/UserList')
      },
      {
        path: '/news-list.html',
        component: ()=>import('../views/news/NewsList')
      },
      {
        path: '/comment.html',
        component: ()=>import('../views/news/Comment')
      }
    ]
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
