package com.xuetang9.tree_new_bee.util.jdbc;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 老九学堂
 * @copyright 老九学堂
 */
@Data
public class JdbcTemplate {
	@Autowired
	private DataSource dataSource;
//    private String driver = "com.mysql.cj.jdbc.Driver";
//
//    private String url = "jdbc:mysql://192.168.66.10:3308/tree_new_bee?serverTimezone=Asia/Shanghai&useUnicode=true&characterEncoding=utf-8&useSSL=false&allowPublicKeyRetrieval=true";
//
//    private String user = "root";
//
//    private String password = "123456";

	/**
	 * 获取连接对象
	 *
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		return dataSource.getConnection();
//        Class.forName(driver);
//        return DriverManager.getConnection(url, user, password);
	}


	/**
	 * 创建一个可执行的PreparedStatement对象
	 *
	 * @param connection
	 * @param sql
	 * @param params
	 * @return
	 * @throws SQLException
	 */
	public PreparedStatement createPreparedStatement(Connection connection, String sql, Object... params) throws SQLException {
		// 1. 创建执行SQL语句的对象
		PreparedStatement pstmt = connection.prepareStatement(sql);
		// 2. 设置参数
		if (params != null && params.length > 0) {
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject(i + 1, params[i]);
			}
		}
		// 3. 返回对象
		return pstmt;
	}
	
	
	/**
	 * 执行SQL增加、删除、修改
	 *
	 * @param sql
	 * @param params
	 * @return
	 */
	public int executeUpdate(String sql, Object... params) {
		// 1. 获得连接对象
		try (Connection connection = getConnection()) {
			// 2. 获得执行的PreparedStatement对象
			try (PreparedStatement pstmt = createPreparedStatement(connection, sql, params)) {
				// 3. 执行SQL并得到结果
				return pstmt.executeUpdate();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public <T> List<T> executeQuery(String sql, RowMapper<T> rowMapper, Object... params) {
		List<T> list = new ArrayList<T>();
		// 1. 获得连接对象
		try (Connection connection = getConnection()) {
			// 2. 获得执行的PreparedStatement对象
			try (PreparedStatement pstmt = createPreparedStatement(connection, sql, params)) {
				// 3. 执行SQL并得到结果
				ResultSet resultSet = pstmt.executeQuery();
				// 4. 封装查询结果为一个集合
				while (resultSet.next()) {
					// 读取每行的数据转换为一个对象 row to object
					T record = rowMapper.rowToObject(resultSet);
					// 添加到集合中
					list.add(record);
				}
				return list;
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public <T> T executeQueryOne(String sql, RowMapper<T> rowMapper, Object... params) {
		T row = null;
		// 1. 获得连接对象
		try (Connection connection = getConnection()) {
			// 2. 获得执行的PreparedStatement对象
			try (PreparedStatement pstmt = createPreparedStatement(connection, sql, params)) {
				// 3. 执行SQL并得到结果
				ResultSet resultSet = pstmt.executeQuery();
				// 4. 封装查询结果为一个集合
				if (resultSet.next()) {
					// 读取每行的数据转换为一个对象 row to object
					row = (T) rowMapper.rowToObject(resultSet);
				}
				return row;
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public Object executeQueryUnique(String sql, Object... params) {
		Object value = null;
		// 1. 获得连接对象
		try (Connection connection = getConnection()) {
			// 2. 获得执行的PreparedStatement对象
			try (PreparedStatement pstmt = createPreparedStatement(connection, sql, params)) {
				// 3. 执行SQL并得到结果
				ResultSet resultSet = pstmt.executeQuery();
				// 4. 封装查询结果为一个集合
				if (resultSet.next()) {
					// 读取唯一的值
					value = resultSet.getObject(1);
				}
				return value;
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
}
