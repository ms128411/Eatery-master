package com.xuetang9.tree_new_bee.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 登录需要的数据
 * @author ZhangChuanWei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginQuery {
    private String userName;

    private String passWord;
}
