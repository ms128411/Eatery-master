package com.xuetang9.tree_new_bee_front.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/10:51
 * @Description: 前台首页请求
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsHomeQuery {
    Integer id;
    Integer type;
    Integer pageIndex;
    Integer pageSize;

    public NewsHomeQuery(Integer type, Integer pageIndex, Integer pageSize) {
        this.type = type;
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
    }
}
