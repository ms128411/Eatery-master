package com.xuetang9.tree_new_bee.dao;

import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.vo.NewsCommentVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;

import java.util.List;

/**
 * @author ZhangChuanWei
 */
public interface NewsCommentDao {
    /**
     * 查询数据的总条数
     *
     * @return
     */
    int selectCount(int id);


    /**
     * 根据条件查询数据
     * @param id
     * @param pageIndex
     * @param pageSize
     * @return
     */
    PageResult<NewsCommentVo> selectList(Integer id, Integer pageIndex, Integer pageSize,int total);


}
