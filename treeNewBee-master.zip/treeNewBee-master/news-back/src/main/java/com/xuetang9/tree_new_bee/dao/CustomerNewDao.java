package com.xuetang9.tree_new_bee.dao;

import com.xuetang9.tree_new_bee.domain.dto.UserDto;

public interface CustomerNewDao {
    /**
     * 查询用户是否存在
     * @param userName
     * @return
     */
    int selectAccount(String userName);
    /**
     * 添加用户
     * @param userDto
     * @return
     */
    int inserOne(UserDto userDto);
}
