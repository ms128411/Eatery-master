package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.NewsCommentQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsCommentVo;
import com.xuetang9.tree_new_bee.service.NewsCommentService;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author ZhangChuanWei
 */
@WebServlet("/newsComment")
public class NewsCommentListServlet extends HttpServlet {

    private NewsCommentQuery newCommentQuery = new NewsCommentQuery();
    @Autowired
    private NewsCommentService newsCommentService;


    /**
     * 重写init方法
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        //让Spring容器自动把Servlet注入到Spring IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //定义响应的结果
        JsonResult<PageResult<NewsCommentVo>> jsonResult = new JsonResult<>();

        //1.获取请求的参数
        int id = ServletUtils.getParameter(request,"id",-1);
        int pageIndex = ServletUtils.getParameter(request, "pageIndex", 1);
        int pageSize = ServletUtils.getParameter(request, "pageSize", 10);
        //2.获取数据总条数
        int total = newsCommentService.queryCount(id);
        if (total == 0){
            return;
        }
        //3.把参数封装为一个对象
        //newCommentQuery = new NewsCommentQuery(id,user_id,pageIndex,pageSize);
        newCommentQuery = new NewsCommentQuery(pageIndex,pageSize,id,total);
        //4.调用服务层方法
        PageResult<NewsCommentVo> pageResult = newsCommentService.listByPageAndCondition(newCommentQuery);

        //5.组装结果
        jsonResult.setStatus(200);
        jsonResult.setData(pageResult);
        //6.响应结果并返回
        ServletUtils.writeJsonObject(response,jsonResult);

    }
}
