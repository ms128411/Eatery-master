package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.query.CommentRecommendQuery;

/**
 * 评论置顶的service接口
 * @author ZhangChuanWei
 */
public interface CommentRecommendService {
    /**
     * 服务层新闻置顶的方法
     * @param commentRecommendQuery
     * @return
     */
    int topNewsComment(CommentRecommendQuery commentRecommendQuery);

}
