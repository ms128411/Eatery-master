package com.xuetang9.tree_new_bee.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 对应数据库中User表结构
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private Integer id;

    private String userName;

    private String passWord;

    private String phone;

    private String realName;

    private String email;
}
