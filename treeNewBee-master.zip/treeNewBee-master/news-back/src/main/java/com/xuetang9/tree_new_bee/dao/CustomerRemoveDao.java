package com.xuetang9.tree_new_bee.dao;

public interface CustomerRemoveDao {
    int removeOne(int id);
}
