package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.CommentRecommendQuery;
import com.xuetang9.tree_new_bee.service.CommentRecommendService;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 新闻置顶servlet
 * @author ZhangChuanWei
 */
@WebServlet("/newsRecommend")
public class NewsCommentIsRecommendServlet extends HttpServlet {

    @Autowired
    private CommentRecommendService recommendService;


    /**
     * 重写init方法
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        //让Spring容器自动把Servlet注入到Spring IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //创建json对象用来保存响应的数据
        JsonResult<Integer> jsonResult = new JsonResult<>();
        //1.获取请求的参数
        Integer id = ServletUtils.getParameterInteger(request, "id");
        Integer zd = ServletUtils.getParameterInteger(request, "zd");
        //2.构建参数
        CommentRecommendQuery commentRecommendQuery = new CommentRecommendQuery(id,zd);
        //3.调用service方法
        int commentRecommendVo = recommendService.topNewsComment(commentRecommendQuery);
        //4.组装数据
        jsonResult.setStatus(200);
        jsonResult.setMessage("修改成功！");
        jsonResult.setData(commentRecommendVo);
        //5.响应
        ServletUtils.writeJsonObject(response,jsonResult);
    }
}
