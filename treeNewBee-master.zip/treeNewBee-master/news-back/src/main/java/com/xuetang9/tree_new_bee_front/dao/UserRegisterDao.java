package com.xuetang9.tree_new_bee_front.dao;

import com.xuetang9.tree_new_bee_front.domain.entity.User;

public interface UserRegisterDao {
    int selectAccount(String userName);

    int inserOne(User user);
}
