package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.entity.Customer;
import com.xuetang9.tree_new_bee.service.CustomerUpDateService;

import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 修改用户数据
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@WebServlet("/customer/Update")
public class CustomerUpDateServlet extends HttpServlet {
    @Autowired
    private CustomerUpDateService customerUpDateService;
    @Autowired
    private JsonResult json = new JsonResult();
    @Override
    public void init() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端传递的值
        int id = ServletUtils.getParameter(req, "id", -1);
        String userName = ServletUtils.getParameter(req, "userName");
        String phone = ServletUtils.getParameter(req, "phone");
        String name = ServletUtils.getParameter(req,"realName");
        String mail = ServletUtils.getParameter(req, "email");
        Customer customer = new Customer(id,userName,"",phone,name,mail);
        if( StringUtils.isNullOrWhitespace(userName)){
            json.setMessage("账户不能为空");
            ServletUtils.writeJsonObject(resp,json);
            return;
        }

        //调用服务层修改数据
        boolean yes = customerUpDateService.upDateOne(customer);
        json.setStatus(200);
        //判断是否修改
        if(!yes){
            json.setCode("A0001");
            json.setMessage("修改失败");
        }else{
            json.setCode("00000");
            json.setMessage("修改成功");
        }
        ServletUtils.writeJsonObject(resp,json);

    }
    
}
