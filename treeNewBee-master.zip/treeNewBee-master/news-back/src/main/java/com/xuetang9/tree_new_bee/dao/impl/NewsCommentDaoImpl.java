package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.NewsCommentDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.vo.NewsCommentVo;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Dao层的实现类
 * @author ZhangChuanWei
 */
@Data
public class NewsCommentDaoImpl implements NewsCommentDao {
private JdbcTemplate jdbcTemplate;
private NewsCommentVo newsCommentVo;
private PageResult pageResult;

    @Override
    public int selectCount(int id) {
        String sql = "select count(*) from comment where news_id = ? and display = 0";
        Object value = jdbcTemplate.executeQueryUnique(sql,id);
        return Integer.parseInt(value.toString());
    }

    @Override
    public PageResult<NewsCommentVo> selectList(Integer id, Integer pageIndex, Integer pageSize, int total) {
        String sql = "select c.display, c.id,c.content,n.title,u.userName,c.zd from comment as c " +
                "join news as n on n.id = c.news_id " +
                "join user as u on u.id = c.user_id " +
                "where c.news_id = ? ";
        //构建参数
        List<Object> params = new ArrayList<>();
        RowMapper<NewsCommentVo> rowMapper = new RowMapper<NewsCommentVo>() {
            @Override
            public NewsCommentVo rowToObject(ResultSet resultSet) throws SQLException {
                NewsCommentVo newsCommentVo = new NewsCommentVo();
                newsCommentVo.setId(resultSet.getInt("id"));
                newsCommentVo.setTitle(resultSet.getString("title"));
                newsCommentVo.setContent(resultSet.getString("content"));
                newsCommentVo.setName(resultSet.getString("userName"));
                newsCommentVo.setZd(resultSet.getInt("zd"));
                return newsCommentVo;
            }
        };

        //构建分页的数据
        sql += " and c.display = 0 limit ?,?";
        params.add(id);
        params.add((pageIndex - 1) * 10);
        params.add(pageSize);
        List<NewsCommentVo> newsCommentVos = jdbcTemplate.executeQuery(sql,rowMapper,params.toArray());
        pageResult.setRows(newsCommentVos);
        pageResult.setPageIndex(pageIndex);
        pageResult.setPageSize(pageSize);
        pageResult.setTotal(total);
        return pageResult;
    }
}
