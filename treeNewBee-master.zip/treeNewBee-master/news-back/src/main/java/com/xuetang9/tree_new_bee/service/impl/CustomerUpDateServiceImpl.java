package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CustomerUpDateDao;
import com.xuetang9.tree_new_bee.domain.entity.Customer;
import com.xuetang9.tree_new_bee.service.CustomerUpDateService;
import lombok.Data;
import org.springframework.stereotype.Service;


/**
 * 修改用户服务层
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data

public class CustomerUpDateServiceImpl implements CustomerUpDateService {

    private CustomerUpDateDao customerUpDateDao;

    /**
     * 判断是否修改成功
     * @param customer
     * @return
     */
    @Override
    public boolean upDateOne(Customer customer) {
        return customerUpDateDao.upDateOne(customer) > 0 ;

    }
}
