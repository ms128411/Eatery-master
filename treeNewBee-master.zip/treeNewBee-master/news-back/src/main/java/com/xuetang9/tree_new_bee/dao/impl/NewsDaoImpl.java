package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.NewsDao;
import com.xuetang9.tree_new_bee.domain.entity.News;
import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/23/10：00
 * @Description: 新闻DAO层实现类
 */
@Data
public class NewsDaoImpl implements NewsDao {

    private JdbcTemplate jdbcTemplate;
    //获取新闻列表
    @Override
    public List<NewsVo> getNewsList(NewsQuery newsQuery) {
        String sql = " SELECT * FROM `news` where 1=1  " ;
        List<Object> params = new ArrayList<>();
        if (!StringUtils.isNullOrWhitespace(newsQuery.getTitle())) {
            sql += " and title LIKE ? ";
            params.add("%"+newsQuery.getTitle()+"%");
        }
        sql += " ORDER BY createTime DESC Limit ? , ? ";
        params.add((newsQuery.getPageIndex()- 1)  * newsQuery.getPageSize());
        params.add(newsQuery.getPageSize());
        System.out.println((newsQuery.getPageIndex()- 1)  * newsQuery.getPageSize());
        System.out.println(newsQuery.getPageSize());

        RowMapper<NewsVo> rowMapper = new RowMapper<NewsVo>() {
            @Override
            public NewsVo rowToObject(ResultSet rs) throws SQLException {
                NewsVo newsVo = new NewsVo();
                newsVo.setId(rs.getInt("id"));
                newsVo.setTitle(rs.getString("title"));
                newsVo.setType(rs.getInt("type"));
                newsVo.setDjs(rs.getInt("djs"));
                newsVo.setPublicTime(rs.getDate("createTime").toString());
                newsVo.setZz(rs.getString("zz"));
                return newsVo;
            }
        };
        return jdbcTemplate.executeQuery(sql, rowMapper, params.toArray());
    }
    //获取新闻总数
    @Override
    public int getCount(NewsQuery newsQuery) {
        String sql = " select count(*) from `news` where 1=1 ";
        List<Object> params = new ArrayList<>();
        if (!StringUtils.isNullOrWhitespace(newsQuery.getTitle())) {
            sql += " and title LIKE ? ";
            params.add("%"+newsQuery.getTitle()+"%");
        }
        Object value = jdbcTemplate.executeQueryUnique(sql,params.toArray());
        return Integer.parseInt(value.toString());
    }
    //添加新闻
    @Override
    public int newsAdd(News news) {
        String sql = "INSERT INTO news (createTime,djs,title,zz,type,content ";
        String sqlKey = "";
        String sqlValue = ") VALUES (?,?, ?,?,?,? ";
        List<Object> params = new ArrayList<>();
        params.add(news.getPublicTime());
        params.add(0);
        params.add(news.getTitle());
        params.add(news.getZz());
        params.add(news.getType());
        params.add(news.getContent());
        if (!StringUtils.isNullOrWhitespace(news.getIntroduction())) {
            sqlKey += ",introduction";
            sqlValue += ",? )";
            params.add(news.getIntroduction());
        } else {
            sqlValue += " ) ";
        }
        sql += sqlKey;
        sql += sqlValue;
        return jdbcTemplate.executeUpdate(sql, params.toArray());
    }
    //新闻删除
    @Override
    public int newsDel(NewsQuery newsQuery) {
        String sql = "DELETE FROM news WHERE id = ?";
        return jdbcTemplate.executeUpdate(sql, newsQuery.getId());
    }

    @Override
    public int newsUpdata(News news) {
        String sql = "UPDATE news SET ";
        List<Object> params = new ArrayList<>();
//        if (!StringUtils.isNullOrWhitespace(news.getTitle())) {
//            sql += " title = ? ,";
//            params.add(news.getTitle());
//        }
        if (news.getType() != null) {
            sql += " type = ? ,";
            params.add(news.getType());
        }
        if (!StringUtils.isNullOrWhitespace(news.getIntroduction())) {
            sql += " introduction = ? ,";
            params.add(news.getIntroduction());
        }
        if (!StringUtils.isNullOrWhitespace(news.getContent())) {
            sql += " content = ? ,";
            params.add(news.getContent());
        }
        if (!StringUtils.isNullOrWhitespace(news.getZz())) {
            sql += " zz = ? ,";
            params.add(news.getZz());
        }
        sql = sql.substring(0, sql.length() - 1);
        sql += " WHERE title = ? ";
        params.add(news.getTitle());
        return jdbcTemplate.executeUpdate(sql, params.toArray());
    }
}
