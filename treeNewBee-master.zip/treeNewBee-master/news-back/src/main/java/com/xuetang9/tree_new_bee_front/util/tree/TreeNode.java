package com.xuetang9.tree_new_bee_front.util.tree;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 用来定义一个统一的树形结构的节点数据
 *
 * @author 老九学堂
 * @copyright 老九学堂
 */
@Data
public class TreeNode<T, ID> implements Serializable {

    /**
     * 树形节点的编号
     */
    private ID id;

    /**
     * 树形节点的父级编号
     */
    private ID pid;

    /**
     * 树形节点显示的文本
     */
    private String text;

    /**
     * 树形节点显示的图标
     */
    private String icon;

    /**
     * 树形节点的链接地址
     */
    private String href;

    /**
     * 树形节点的深度
     */
    private Integer depth;

    /**
     * 是否是叶子节点
     */
    private Boolean leaf;

    /**
     * 当前节点包含的子节点信息
     */
    private List<TreeNode<T, ID>> children;

    /**
     * 保存节点转换前的原始数据
     */
    private T raw;
}
