package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.dto.UserDto;

public interface CustomerNewService {
    boolean selectAccount(String userName);

    boolean insertOne(UserDto userDto);
}
