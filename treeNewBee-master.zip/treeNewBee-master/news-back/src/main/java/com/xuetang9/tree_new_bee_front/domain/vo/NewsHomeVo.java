package com.xuetang9.tree_new_bee_front.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/10:55
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsHomeVo {
    /** id */
    private Integer id;

    /** content */
    private String content;

    /** createTime */
    private String createTime;

    /** djs */
    private Integer djs;

    /** introduction */
    private String introduction;

    /** title */
    private String title;

    /** zz */
    private String zz;

    /** type */
    private Integer type;
}
