package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.CommentDeleteQuery;
import com.xuetang9.tree_new_bee.service.CommentDeleteService;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 新闻评论删除的Servlet
 * @author ZhangChuanWei
 */
@WebServlet("/deleteComment")
public class NewCommentDeleteServlet extends HttpServlet {

    @Autowired
    private CommentDeleteService commentDeleteService;


    /**
     * 重写init方法
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        //让Spring容器自动把Servlet注入到Spring IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //创建json对象保存响应数据
        JsonResult<Integer> jsonResult = new JsonResult<>();

        //获取请求的参数
        Integer id = ServletUtils.getParameterInteger(request, "id");
        //数据校验
        Map<String,String> errors = new HashMap<>();
        if (id == null){
            errors.put("id","id不能为空");
        }
        //响应校验的结果
        if (!errors.isEmpty()){
            jsonResult.setStatus(200);
            jsonResult.setError(errors);
            jsonResult.setMessage("参数错误");
            ServletUtils.writeJsonObject(response,jsonResult);
            return;
        }
        //构建参数
        CommentDeleteQuery commentDeleteQuery = new CommentDeleteQuery(id);
        //调用业务层方法
        int newsCommentVo = commentDeleteService.deleteById(commentDeleteQuery);
        //组装数据
        jsonResult.setStatus(200);
        jsonResult.setMessage("删除成功！");
        jsonResult.setData(newsCommentVo);
        //响应数据
        ServletUtils.writeJsonObject(response,jsonResult);







    }
}
