package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CustomerNewDao;
import com.xuetang9.tree_new_bee.domain.dto.UserDto;
import com.xuetang9.tree_new_bee.service.CustomerNewService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 新增用户服务层
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data

public class CustomerNewServiceImpl implements CustomerNewService {
    @Autowired
    private CustomerNewDao customerNewDao;

    /**
     * 查找用户名是否已存在
     * @param userName
     * @return
     */
    @Override
    public boolean selectAccount(String userName) {
        return customerNewDao.selectAccount(userName) > 0;
    }

    /**
     * 添加用户,并返回是否添加成功
     * @param userDto
     * @return
     */
    @Override
    public boolean insertOne(UserDto userDto) {
        return customerNewDao.inserOne(userDto) > 0;

    }
}
