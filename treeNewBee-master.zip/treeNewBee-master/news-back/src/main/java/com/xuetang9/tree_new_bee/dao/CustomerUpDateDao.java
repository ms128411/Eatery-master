package com.xuetang9.tree_new_bee.dao;


import com.xuetang9.tree_new_bee.domain.entity.Customer;

public interface CustomerUpDateDao {
    int upDateOne(Customer customer);
}
