package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;

import java.util.List;

public interface NewsService {
    //获取新闻列表
    PageResult<NewsVo> getNewsList(NewsQuery newsQuery);

    boolean newsAdd(NewsQuery newsQuery);

    boolean newsDel(NewsQuery newsQuery);

    boolean newsUpdata(NewsQuery newsQuery);
}
