package com.xuetang9.tree_new_bee_front.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @desc： 前台登录展示数据VO
 * @Author: luoChen
 * @Date: 2021/7/27 10:31
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class FrontLoginVo {
	private Integer id;
	private String userName;
	private String passWord;
	private String phone;
	private String realName;
	private String email;
}
