package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CustomerUpDateDao;
import com.xuetang9.tree_new_bee.domain.entity.Customer;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import lombok.Data;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户修改数据操作层
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data
public class CustomerUpDateDaoImpl implements CustomerUpDateDao {

    private JdbcTemplate jdbc;

    /**
     * 修改用户数据
     * @param customer
     * @return
     */
    @Override
    public int upDateOne(Customer customer) {
        String sql = "update user set ";
        List<Object> params = new ArrayList<>();
        Field[] declaredFields = customer.getClass().getDeclaredFields();
        for (Field field : declaredFields){
            field.setAccessible(true);
            try {
                Object value = field.get(customer);
                if(field.getName().equals("id")){
                    continue;
                }
                if(value != null){
                    sql += field.getName() + " = ?,";
                    params.add(value);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        sql = sql.substring(0,sql.length() - 1);
        sql += " where id = ? ";
        params.add(customer.getId());
        return jdbc.executeUpdate(sql, params.toArray());

    }
}
