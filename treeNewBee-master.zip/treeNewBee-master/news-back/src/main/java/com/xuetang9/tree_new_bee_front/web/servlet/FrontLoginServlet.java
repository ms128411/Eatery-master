package com.xuetang9.tree_new_bee_front.web.servlet;

import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import com.xuetang9.tree_new_bee_front.domain.query.FrontLoginQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.FrontLoginVo;
import com.xuetang9.tree_new_bee_front.service.FrontUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc： 前台登录servlet
 * @Author: luoChen
 * @Date: 2021/7/27 10:23
 */
@WebServlet("/front/login")
public class FrontLoginServlet extends HttpServlet {
	@Autowired
	private FrontLoginQuery frontLoginQuery;
	@Autowired
	private FrontLoginVo frontLoginVo;
	@Autowired
	private FrontUserService frontUserService;
	@Override
	public void init() throws ServletException {
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
		super.init();
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 定义响应结构
		JsonResult<FrontLoginVo> jsonResult = new JsonResult<>();
		// 获取响应参数
		String userName = ServletUtils.getParameter(request, "userName");
		String passWord = ServletUtils.getParameter(request, "passWord");
		// 表单验证
		Map<String,String> errors = new HashMap<>();
		if (userName.isEmpty()){
			errors.put("userName","账号必填");
		}
		if (passWord.isEmpty()){
			errors.put("passWord","密码必填");
		}
		// 判断表单验证是否通过
		if (!errors.isEmpty()){
			jsonResult.setError(errors);
			jsonResult.setStatus(200);
			jsonResult.setCode("A0001");
			jsonResult.setMessage("登录参数错误！");
			ServletUtils.writeJsonObject(response,jsonResult);
			return;
		}
		// 构建参数对象
		frontLoginQuery.setUserName(userName);
		frontLoginQuery.setPassWord(passWord);
		// 调用业务层代码
		frontLoginVo = frontUserService.login(frontLoginQuery);
		// 判断登录业务是否成功
		if (frontLoginVo == null){
			// 登录失败
			jsonResult.setStatus(200);
			jsonResult.setCode("A0002");
			jsonResult.setMessage("账号或者密码错误！");
			// 响应
			ServletUtils.writeJsonObject(response, jsonResult);
			return;
		}
		// 登录成功，把用户信息保存在session中
		HttpSession session = request.getSession();
		session.setAttribute("LOGIN_TICKET",frontLoginVo);
		// 响应
		jsonResult.setStatus(200);
		jsonResult.setData(frontLoginVo);
		ServletUtils.writeJsonObject(response,jsonResult);
	}
}
