package com.xuetang9.tree_new_bee.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
public class CustomerVo implements Serializable {
    private Integer id;
    private String userName;
    private String phone;
    private String realName;
    private String email;
}
