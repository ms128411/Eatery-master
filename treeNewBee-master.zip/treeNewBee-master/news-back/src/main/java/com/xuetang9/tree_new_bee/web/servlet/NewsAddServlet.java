package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.service.NewsService;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/25/10:49
 * @Description:  新闻添加
 */
@WebServlet("/newsAdd")
public class NewsAddServlet extends HttpServlet {
    @Autowired
    private NewsService newsService;

    @Override
    public void init() throws ServletException {
        //让Spring IoC容器自动把Servlet注入IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult<String> jsonResult = new JsonResult<>();
        String title = ServletUtils.getParameter(req, "title");
        String zz = ServletUtils.getParameter(req, "zz");
        String introduction ="原标题："+ ServletUtils.getParameter(req, "introduction");
        Integer type = ServletUtils.getParameterInteger(req, "type");
        String content = ServletUtils.getParameter(req, "content");
        String time = ServletUtils.getParameter(req, "publicTime");
        NewsQuery newsQuery = new NewsQuery(title, zz, introduction, type, content,time);
        Map<String,String> errors = new HashMap<>();
        if (newsService.newsAdd(newsQuery)) {
            jsonResult.setStatus(200);
            jsonResult.setMessage("添加成功");
            ServletUtils.writeJsonObject(resp,jsonResult);
        } else {
            errors.put("warning", "缺少必填项");
            jsonResult.setCode("A00099");
            jsonResult.setStatus(200);
            jsonResult.setError(errors);
            jsonResult.setMessage("参数错误");
            ServletUtils.writeJsonObject(resp,jsonResult);
        }
        ;
    }
}
