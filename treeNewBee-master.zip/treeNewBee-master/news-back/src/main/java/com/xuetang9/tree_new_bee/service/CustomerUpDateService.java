package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.entity.Customer;

/**
 * 修改用户服务层
 * 作者：周威
 */
public interface CustomerUpDateService {
    boolean upDateOne(Customer customer);
}
