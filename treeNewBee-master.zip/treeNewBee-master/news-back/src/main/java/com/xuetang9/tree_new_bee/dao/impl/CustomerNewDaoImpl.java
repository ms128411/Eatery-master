package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CustomerNewDao;
import com.xuetang9.tree_new_bee.domain.dto.UserDto;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * 新增用户
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data
@Repository
public class CustomerNewDaoImpl implements CustomerNewDao {
    @Autowired
    private JdbcTemplate jdbc;

    /**
     * 查询用户是否存在
     * @param userName
     * @return
     */
    @Override
    public int selectAccount(String userName) {
        String sql = "select count(*) from user where userName = ?";
        Object o = jdbc.executeQueryUnique(sql, userName);
        return Integer.parseInt(o.toString());

    }

    /**
     * 添加用户
     * @param userDto
     * @return
     */
    @Override
    public int inserOne(UserDto userDto) {
        String sql = "insert into user values(null,?,?,?,?,?,0)";
        List<Object> params = new ArrayList<>();
        Field[] declaredFields = userDto.getClass().getDeclaredFields();
        for(Field field : declaredFields){
            field.setAccessible(true);
            try {
                Object value = field.get(userDto);
                params.add(value);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }

        }
        return jdbc.executeUpdate(sql,params.toArray());
    }
}
