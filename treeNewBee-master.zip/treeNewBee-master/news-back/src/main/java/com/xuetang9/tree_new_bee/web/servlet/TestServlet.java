package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @desc：
 * @Author: luoChen
 * @Date: 2021/7/22 10:46
 */
@WebServlet("/test")
public class TestServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 接收前端数据
		String test = ServletUtils.getParameter(request, "test");
		System.out.println(test);
		// 创建json对象
		JsonResult jsonResult = new JsonResult();
		jsonResult.setStatus(200);
		jsonResult.setCode("A0001");
		jsonResult.setMessage("链接失败");
		jsonResult.setData("失败");
		// 发送JSON数据给前端
		ServletUtils.writeJsonObject(response, jsonResult);
	}
}
