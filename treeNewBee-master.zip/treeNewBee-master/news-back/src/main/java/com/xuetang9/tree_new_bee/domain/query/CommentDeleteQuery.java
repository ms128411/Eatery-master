package com.xuetang9.tree_new_bee.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 要查询的数据，对应用户请求的数据
 * @author ZhangChuanWei
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommentDeleteQuery {
    private Integer id;
}
