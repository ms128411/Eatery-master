package com.xuetang9.tree_new_bee.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * 要查询的数据
 * @author ZhangChuanWei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor

public class NewsCommentQuery implements Serializable {

    /**
     * 页面显示的页码
     */
    private Integer pageIndex;

    /**
     * 页面中每页显示的数据
     */
    private Integer pageSize;

    /**
     * 对应新闻表中要评论的新闻id
     */
    private Integer id;

    private Integer total;




   /* private String title;

    private String context;

    private String name;

    private Integer zd;*/


}
