package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CommentDeleteDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.entity.Manage;
import com.xuetang9.tree_new_bee.service.CommentDeleteService;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import lombok.Data;

/**
 * 删除评论的dao层实现类
 * @author ZhangChuanWei
 */
@Data
public class CommentDeleteDaoImpl implements CommentDeleteDao {
    private JdbcTemplate jdbcTemplate;
    @Override
    public int removeCommentById(Comment comment) {
        //定义sql语句
        String sql = "update comment set display = case display when 0 then 1 end where id = ? ";
        //构建参数
        Object[] params = {comment.getId()};
        return jdbcTemplate.executeUpdate(sql,params);
    }
}
