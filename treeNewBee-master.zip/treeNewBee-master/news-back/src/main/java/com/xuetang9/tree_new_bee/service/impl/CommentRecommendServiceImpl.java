package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CommentRecommendDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.entity.Manage;
import com.xuetang9.tree_new_bee.domain.query.CommentRecommendQuery;
import com.xuetang9.tree_new_bee.service.CommentRecommendService;
import lombok.Data;

/**
 * @author ZhangChuanWei
 */
@Data
public class CommentRecommendServiceImpl implements CommentRecommendService {
    private Comment comment;
    private CommentRecommendDao recommendDao;
    @Override
    public int topNewsComment(CommentRecommendQuery commentRecommendQuery) {
        //把页面数据转换为数据库操作所需的参数
        comment.setId(commentRecommendQuery.getId());
        comment.setZd(commentRecommendQuery.getZd());
        return recommendDao.isTop(comment);
    }
}
