package com.xuetang9.tree_new_bee_front.service;

import com.xuetang9.tree_new_bee_front.domain.query.FrontLoginQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.FrontLoginVo;

/**
 * @desc： 登录业务服务层
 * @Author: luoChen
 * @Date: 2021/7/27 15:24
 */
public interface FrontUserService {
	/**
	 * description: 登录功能
	 *
	 * @param frontLoginQuery
	 * @return com.xuetang9.tree_new_bee_front.domain.vo.FrontLoginVo
	 */
	FrontLoginVo login(FrontLoginQuery frontLoginQuery);
}
