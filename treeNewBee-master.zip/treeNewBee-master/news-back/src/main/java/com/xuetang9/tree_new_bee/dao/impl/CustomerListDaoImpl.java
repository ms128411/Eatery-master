package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CustomerListDao;
import com.xuetang9.tree_new_bee.domain.vo.CustomerVo;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import lombok.Data;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户列表查询
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data
@Repository
public class CustomerListDaoImpl implements CustomerListDao {

    private JdbcTemplate jdbc;

    /**
     * 获取用户数据总数
     *
     * @return
     */
    @Override
    public int selectSum(String realName) {
        String sql = "select count(*) from user where display = 0 ";
        List<Object> params = new ArrayList<>();
        if (!StringUtils.isNullOrWhitespace(realName)) {
            sql += " and userName like ? ";
            params.add("%" + realName + "%");
        }
        Object sum = jdbc.executeQueryUnique(sql, params.toArray());
        return Integer.parseInt(sum.toString());
    }

    /**
     * 获取用户分页数据
     *
     * @param realName
     * @param pageIndex
     * @param pageSize
     * @param sum
     * @return
     */
    @Override
    public PageResult<CustomerVo> selectAll(String realName, int pageIndex, int pageSize, int sum) {
        String sql = "select * from user where 1 = 1 ";
        List<Object> params = new ArrayList<>();
        if (!StringUtils.isNullOrWhitespace(realName)) {
            sql += " and userName like ? ";
            params.add("%"+realName+"%");
        }

        RowMapper<CustomerVo> rowMapper = new RowMapper() {
            @Override
            public Object rowToObject(ResultSet resultSet) throws SQLException {
                CustomerVo customerVo = new CustomerVo();
                customerVo.setId(resultSet.getInt("id"));
                customerVo.setUserName(resultSet.getString("userName"));
                customerVo.setPhone(resultSet.getString("phone"));
                customerVo.setRealName(resultSet.getString("realName"));
                customerVo.setEmail(resultSet.getString("email"));
                return customerVo;
            }
        };

        int index = (pageIndex-1) * 10;
        sql += " and display = 0 limit ?,?";
        params.add(index);
        params.add(pageSize);
        List<CustomerVo> customerVos = jdbc.executeQuery(sql, rowMapper, params.toArray());
        PageResult<CustomerVo> pageResult = new PageResult<>(customerVos, pageIndex, pageSize, sum);
        return pageResult;
    }

}
