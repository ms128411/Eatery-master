package com.xuetang9.tree_new_bee_front.dao.impl;

import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import com.xuetang9.tree_new_bee_front.dao.FrontUserDao;
import com.xuetang9.tree_new_bee_front.domain.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @desc：
 * @Author: luoChen
 * @Date: 2021/7/27 15:32
 */
@Repository
public class FrontUserDaoImpl implements FrontUserDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//@Autowired
	private User user = new User();
	
	@Override
	public User selectOne(User condition) {
		String sql = "select * from user where userName = ? and passWord = ?";
		Object[] params = {condition.getUserName(),condition.getPassWord()};
		RowMapper<User> userRowMapper = new RowMapper<User>() {
			@Override
			public User rowToObject(ResultSet resultSet) throws SQLException {
				user.setId(resultSet.getInt("id"));
				user.setUserName(resultSet.getString("userName"));
				user.setPassWord(resultSet.getString("passWord"));
				user.setPhone(resultSet.getString("phone"));
				user.setRealName(resultSet.getString("realName"));
				user.setEmail(resultSet.getString("email"));
				return user;
			}
		};
		return jdbcTemplate.executeQueryOne(sql,userRowMapper,params);
	}
}
