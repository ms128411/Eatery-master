package com.xuetang9.tree_new_bee.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc 对应数据库中manage表结构
 * @author ZhangChuanWei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Manage {

    private Integer id;

    private String userName;

    private String passWord;

    private String realName;


}
