package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.query.LoginQuery;
import com.xuetang9.tree_new_bee.domain.vo.LoginVo;

/**
 * @author ZhangChuanWei
 */
public interface UserService {
    /**
     * 登录方法
     * @param loginQuery
     * @return
     */
    LoginVo login(LoginQuery loginQuery);
}
