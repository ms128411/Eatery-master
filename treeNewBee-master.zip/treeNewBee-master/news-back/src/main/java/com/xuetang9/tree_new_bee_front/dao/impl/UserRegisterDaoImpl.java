package com.xuetang9.tree_new_bee_front.dao.impl;

import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee_front.dao.UserRegisterDao;
import com.xuetang9.tree_new_bee_front.domain.entity.User;
import lombok.Data;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Data
public class UserRegisterDaoImpl implements UserRegisterDao {
    JdbcTemplate jdbc;
    @Override
    public int selectAccount(String userName) {
        String sql = "select count(0) from user where userName = ? ";
        Object o = jdbc.executeQueryUnique(sql, userName);
        return Integer.parseInt(o.toString());
    }

    @Override
    public int inserOne(User user) {
        String sql = "insert into user values(?,?,?,?,?,?,0)";
        List<Object> params = new ArrayList<>();
        Field[] declaredFields = user.getClass().getDeclaredFields();
        for(Field field : declaredFields){
            field.setAccessible(true);
            try {

                Object value = field.get(user);
                params.add(value);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }

        }
        return jdbc.executeUpdate(sql,params.toArray());
    }
}
