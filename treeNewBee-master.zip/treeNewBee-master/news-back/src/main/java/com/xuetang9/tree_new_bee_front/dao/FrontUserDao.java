package com.xuetang9.tree_new_bee_front.dao;

import com.xuetang9.tree_new_bee_front.domain.entity.User;

/**
 * @desc： 登录数据访问层接口
 * @Author: luoChen
 * @Date: 2021/7/27 15:31
 */
public interface FrontUserDao {
	/**
	 * description: 在数据库中查找登录账号
	 *
	 * @param condition
	 * @return com.xuetang9.tree_new_bee_front.domain.entity.User
	 */
	User selectOne(User condition);
}
