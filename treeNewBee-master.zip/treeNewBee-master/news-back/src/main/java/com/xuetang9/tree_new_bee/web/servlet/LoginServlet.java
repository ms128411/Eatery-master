package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.LoginQuery;
import com.xuetang9.tree_new_bee.domain.vo.LoginVo;
import com.xuetang9.tree_new_bee.service.UserService;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


/**
 * @desc:后端登录的Servlet
 * @author ZhangChuanWei
 */
@WebServlet("/login")
@Data
public class LoginServlet extends HttpServlet {

    private LoginQuery loginQuery;
    private LoginVo loginVo;
    @Autowired
    private UserService userService;

    private ApplicationContext context;

    /**
     * 重写init方法
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {

        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //定义响应的结果
        JsonResult<LoginVo> jsonResult = new JsonResult<>();
        //1.获取请求的参数
        String userName = ServletUtils.getParameter(request, "userName");
        String passWord = ServletUtils.getParameter(request, "passWord");
        //2.表单校验
        Map<String,String> errors = new HashMap<>();
        if (userName.isEmpty()){
            errors.put(userName,"账号不能为空");
        }
        if (passWord.isEmpty()){
            errors.put(passWord,"密码不能为空");
        }
        //3.判断表单验证是否通过
        if (!errors.isEmpty()){
            jsonResult.setCode("A00001");
            jsonResult.setStatus(200);
            jsonResult.setError(errors);
            jsonResult.setMessage("登录参数错误");
            //响应
            ServletUtils.writeJsonObject(response,jsonResult);
            return;
        }
        //4.构建参数对象
        loginQuery = new LoginQuery(userName,passWord);
        //5.调用service层方法
        loginVo = userService.login(loginQuery);
        //6.判断登录业务是否成功
        if (loginVo == null){
            jsonResult.setStatus(200);
            jsonResult.setMessage("账号或密码不正确！");
            //响应
            ServletUtils.writeJsonObject(response,jsonResult);
            return;
        }
        //登录成功后把数据保存到Session对象中
        HttpSession session = request.getSession();
        session.setAttribute("LOGIN_ACCESS",loginVo);
        //响应
        jsonResult.setCode("00000");
        jsonResult.setStatus(200);
        jsonResult.setMessage("登录成功！");
        jsonResult.setData(loginVo);
        ServletUtils.writeJsonObject(response,jsonResult);
    }
}
