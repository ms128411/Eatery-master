package com.xuetang9.tree_new_bee.dao;

import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.entity.Manage;

/**
 * @author ZhangChuanWei
 */
public interface CommentDeleteDao {
    /**
     * 通过Id删除新闻评论
     * @param comment
     * @return
     */
    int removeCommentById(Comment comment);
}
