package com.xuetang9.tree_new_bee_front.service.impl;

import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee_front.dao.NewsHomeDao;
import com.xuetang9.tree_new_bee_front.dao.impl.NewsHomeDaoImpl;
import com.xuetang9.tree_new_bee_front.domain.query.NewsHomeQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.NewsHomeVo;
import com.xuetang9.tree_new_bee_front.service.NewsHomeService;
import lombok.Data;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/10:46
 * @Description: 前台首页服务层实现类
 */
@Data
public class NewsHomeServiceImpl implements NewsHomeService {
    private NewsHomeDao homeDao;
    @Override
    public PageResult<NewsHomeVo> getList(NewsHomeQuery homeQuery) {
        PageResult<NewsHomeVo> pageResult = new PageResult<>();
        int total = homeDao.getCount(homeQuery);
        if (total > 0) {
            pageResult.setRows(homeDao.getList(homeQuery));
        }
        pageResult.setPageIndex(homeQuery.getPageIndex());
        pageResult.setPageSize(homeQuery.getPageSize());
        pageResult.setTotal(total);
        return pageResult;
    }

    @Override
    public NewsHomeVo getCount(NewsHomeQuery homeQuery) {
        return homeDao.getContent(homeQuery);
    }

    @Override
    public List<NewsHomeVo> getnewList(NewsHomeQuery homeQuery) {
        return homeDao.getnewList(homeQuery);
    }
}
