package com.xuetang9.tree_new_bee.web.servlet;


import com.xuetang9.tree_new_bee.domain.vo.CustomerVo;
import com.xuetang9.tree_new_bee.service.CustomerListService;

import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户列表的servlet层
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@WebServlet( "/customerList")
public class CustomerListServlet extends HttpServlet {
    @Autowired
    private CustomerListService customerListService ;

    @Override
    public void init() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult<PageResult> jsonResult = new JsonResult<>();
        //收集数据
        String realName = ServletUtils.getParameter(req, "name");
        int pageIndex = ServletUtils.getParameter(req, "pageIndex", 1);
        int pageSize = ServletUtils.getParameter(req, "pageSize", 10);
        //获取总数据量
        int sum = customerListService.selectSum(realName);
        if (sum == 0) {
            return;
        }
        //调用服务层获取分页数据
        PageResult<CustomerVo> pageResult = customerListService.selectAll(realName, pageIndex, pageSize, sum);
        //拼装返回前端的数据
        jsonResult.setData(pageResult);
        jsonResult.setStatus(200);
        jsonResult.setCode("00000");
        ServletUtils.writeJsonObject(resp, jsonResult);


    }
}
