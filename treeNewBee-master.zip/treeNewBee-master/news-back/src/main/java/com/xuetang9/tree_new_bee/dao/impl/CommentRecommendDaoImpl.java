package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CommentRecommendDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import lombok.Data;

/**
 * @author ZhangChuanWei
 */
@Data
public class CommentRecommendDaoImpl implements CommentRecommendDao {
    private JdbcTemplate jdbcTemplate;
    @Override
    public int isTop(Comment comment) {
        //定义sql语句
        String sql = "update comment set zd = case zd when 0 then 1 or zd when 1 then 0 end where id = ?";
        //构建参数
        Object[] params = {comment.getId()};
        return jdbcTemplate.executeUpdate(sql, params);
    }
}
