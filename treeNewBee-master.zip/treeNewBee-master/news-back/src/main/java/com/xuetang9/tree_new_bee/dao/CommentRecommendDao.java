package com.xuetang9.tree_new_bee.dao;


import com.xuetang9.tree_new_bee.domain.entity.Comment;

/**
 * 评论置顶的dao层
 * @author ZhangChuanWei
 */
public interface CommentRecommendDao {
    int isTop(Comment comment);
}
