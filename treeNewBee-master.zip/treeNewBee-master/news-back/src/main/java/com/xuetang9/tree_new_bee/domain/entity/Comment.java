package com.xuetang9.tree_new_bee.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 对应数据库中Comment表结构
 * @author ZhangChuanWei
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    private Integer id;
    private String content;
    private Date createTime;
    private Integer new_id;
    private Integer user_id;
    private Integer zd;
}
