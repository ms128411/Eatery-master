package com.xuetang9.tree_new_bee.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ZhangChuanWei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentDeleteVo {
    private Integer id;
}
