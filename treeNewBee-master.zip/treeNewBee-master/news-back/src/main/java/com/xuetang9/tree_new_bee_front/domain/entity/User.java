package com.xuetang9.tree_new_bee_front.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * 用户账户实体类
 * 作者：周威
 * 日期：2021年7月27日
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class User {
    private Integer id;
    private String userName;
    private String passWord;
    private String phone;
    private String realName;
    private String email;
}
