package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.dto.UserDto;
import com.xuetang9.tree_new_bee.service.CustomerNewService;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 新增用户
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@WebServlet("/customer/new")
public class CustomerNewServlet extends HttpServlet {
    @Autowired
    private CustomerNewService customerNewService;

    private JsonResult json = new JsonResult();

    @Override
    public void init() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = ServletUtils.getParameter(req, "userName");
        String passWord = ServletUtils.getParameter(req, "passWord");
        String phone = ServletUtils.getParameter(req, "phone");
        String name = ServletUtils.getParameter(req, "name");
        String mail = ServletUtils.getParameter(req, "mail");
        boolean accountExist = customerNewService.selectAccount(userName);
        json.setStatus(200);
        if(StringUtils.isNullOrWhitespace(passWord) || StringUtils.isNullOrWhitespace(userName)){
            json.setMessage("账户或密码不能为空");
            ServletUtils.writeJsonObject(resp,json);
            return;
        }
        if(accountExist){
            json.setCode("A0002");
            json.setMessage("账户已存在");
            ServletUtils.writeJsonObject(resp,json);
            return;
        }
        UserDto userDto = new UserDto(userName, passWord, phone, name, mail);
        boolean succeed = customerNewService.insertOne(userDto);

        if(succeed){
            json.setCode("00000");
            json.setMessage("用户添加成功");
        }else{
            json.setCode("A0001");
            json.setMessage("用户删除失败");
        }
        ServletUtils.writeJsonObject(resp,json);

    }
}
