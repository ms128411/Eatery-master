package com.xuetang9.tree_new_bee_front.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import com.xuetang9.tree_new_bee_front.domain.query.NewsHomeQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.NewsHomeVo;
import com.xuetang9.tree_new_bee_front.service.NewsHomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/28/9:47
 * @Description: 最新新闻数据获取
 */
@WebServlet("/newsNew")
public class NewsNewGet extends HttpServlet {
    @Autowired
    private NewsHomeService homeService;

    @Override
    public void init() throws ServletException {
        //让Spring IoC容器自动把Servlet注入IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult<List<NewsHomeVo>> jsonResult = new JsonResult<>();
        Integer type = ServletUtils.getParameterInteger(req, "type");
        NewsHomeQuery newsQuery =new NewsHomeQuery();
        newsQuery.setType(type);
        List<NewsHomeVo> pageResult = homeService.getnewList(newsQuery);
        jsonResult.setData(pageResult);
        jsonResult.setStatus(200);
        System.out.println("NewNewsType"+type);
        ServletUtils.writeJsonObject(resp, jsonResult);
    }
}
