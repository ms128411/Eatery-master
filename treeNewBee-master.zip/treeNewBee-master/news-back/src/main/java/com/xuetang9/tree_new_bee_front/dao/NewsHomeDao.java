package com.xuetang9.tree_new_bee_front.dao;

import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee_front.domain.query.NewsHomeQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.NewsHomeVo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/10:59
 * @Description:
 */
public interface NewsHomeDao {
    List<NewsHomeVo> getList(NewsHomeQuery homeQuery);

    int getCount(NewsHomeQuery homeQuery);

    NewsHomeVo getContent(NewsHomeQuery homeQuery);

    List<NewsHomeVo> getnewList(NewsHomeQuery homeQuery);
}
