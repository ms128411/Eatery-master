package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.UserDao;
import com.xuetang9.tree_new_bee.domain.entity.Manage;
import com.xuetang9.tree_new_bee.domain.entity.User;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @desc 登录的Dao层实现类
 * @author ZhangChuanWei
 */
@Data
public class UserDaoImpl implements UserDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    private Manage manage;
    @Override
    public Manage selectOne(Manage condition) {
        //定义sql语句
        String sql = "select * from manage where userName = ? and passWord = ?";
        RowMapper<Manage> rowMapper = new RowMapper<Manage>() {
            @Override
            public Manage rowToObject(ResultSet resultSet) throws SQLException {
                manage.setId(resultSet.getInt("id"));
                manage.setUserName(resultSet.getString("userName"));
                manage.setPassWord(resultSet.getString("passWord"));
                manage.setRealName(resultSet.getString("realName"));
                return manage;
            }
        };
        //构建参数
        Object[] params = {condition.getUserName(),condition.getPassWord()};
        return jdbcTemplate.executeQueryOne(sql,rowMapper,params);
    }
}
