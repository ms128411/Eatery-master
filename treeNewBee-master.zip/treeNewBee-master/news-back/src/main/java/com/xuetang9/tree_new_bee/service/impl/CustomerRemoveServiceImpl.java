package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CustomerRemoveDao;
import com.xuetang9.tree_new_bee.service.CustomerRemoveService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 删除用户
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data

public class CustomerRemoveServiceImpl implements CustomerRemoveService {
    @Autowired
    private CustomerRemoveDao customerRemoveDao;

    @Override
    public boolean removeOne(int id) {
        return customerRemoveDao.removeOne(id) > 0;
    }
}
