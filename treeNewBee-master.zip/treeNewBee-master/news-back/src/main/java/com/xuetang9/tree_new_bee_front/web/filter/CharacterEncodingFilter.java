package com.xuetang9.tree_new_bee_front.web.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * @desc： 字符编码过滤器
 * @Author: luoChen
 * @Date: 2021/7/12 13:34
 */
@WebFilter("/*")
public class CharacterEncodingFilter implements Filter {
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		// 设置编码
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		// 放行
		filterChain.doFilter(request,response);
	}
}
