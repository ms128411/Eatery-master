package com.xuetang9.tree_new_bee.domain.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 响应数据实体类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsVo {
    private Integer id;
    private String title;
    private Integer type;
    private Integer djs;
    private String publicTime;
    private String zz;
}
