package com.xuetang9.tree_new_bee.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    private Integer id;
    private String userName;
    private String passWord;
    private String phone;
    private String realName;
    private String email;
}
