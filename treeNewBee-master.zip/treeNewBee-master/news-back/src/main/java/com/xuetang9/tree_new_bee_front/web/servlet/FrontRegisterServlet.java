package com.xuetang9.tree_new_bee_front.web.servlet;


import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import com.xuetang9.tree_new_bee_front.domain.entity.User;
import com.xuetang9.tree_new_bee_front.service.UserRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/register")
public class FrontRegisterServlet extends HttpServlet {
    @Autowired
    private UserRegisterService userRegisterService;

    @Override
    public void init() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult json = new JsonResult();

        String userName = ServletUtils.getParameter(req, "userName");
        String passWord = ServletUtils.getParameter(req, "passWord");
        String phone = ServletUtils.getParameter(req, "phone");
        String name = ServletUtils.getParameter(req, "realName");
        String mail = ServletUtils.getParameter(req, "email");
        //判断账户密码是否为空
        if(StringUtils.isNullOrWhitespace(passWord) || StringUtils.isNullOrWhitespace(userName)){
            json.setMessage("账户或密码不能为空");
            ServletUtils.writeJsonObject(resp,json);
            return;
        }
        //调用服务层，检查账户是否存在
        boolean accountExist = userRegisterService.selectAccount(userName);
        json.setStatus(200);
        if(accountExist){
            json.setCode("A0002");
            json.setMessage("账户已存在");
            ServletUtils.writeJsonObject(resp,json);
            return;
        }
        //组装要注册的账号，并调用服务层注册方法
        User user = new User(null,userName, passWord, phone, name, mail);
        boolean succeed = userRegisterService.insertOne(user);

        if(succeed){
            json.setCode("00000");
            json.setMessage("用户添加成功");
        }else{
            json.setCode("A0001");
            json.setMessage("用户删除失败");
        }
        ServletUtils.writeJsonObject(resp,json);
    }
}
