package com.xuetang9.tree_new_bee.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 界面展示的数据
 * @author ZhangChuanWei
 */
@Data
public class LoginVo implements Serializable {

    private Integer id;

    private String userName;

    private String passWord;
}
