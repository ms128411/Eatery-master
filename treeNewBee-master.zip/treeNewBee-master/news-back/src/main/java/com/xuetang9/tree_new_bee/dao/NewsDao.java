package com.xuetang9.tree_new_bee.dao;

import com.xuetang9.tree_new_bee.domain.entity.News;
import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;

import java.util.List;

public interface NewsDao {


    List<NewsVo> getNewsList(NewsQuery newsQuery);

    int getCount(NewsQuery newsQuery);

    int newsAdd(News news);

    int newsDel(NewsQuery newsQuery);

    int newsUpdata(News news);
}
