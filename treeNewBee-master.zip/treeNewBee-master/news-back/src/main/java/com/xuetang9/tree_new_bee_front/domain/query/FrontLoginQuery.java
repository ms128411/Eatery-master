package com.xuetang9.tree_new_bee_front.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @desc： 前台登录请求参数
 * @Author: luoChen
 * @Date: 2021/7/27 10:29
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class FrontLoginQuery {
	private String userName;
	private String passWord;
}
