package com.xuetang9.tree_new_bee_front.service.impl;


import com.xuetang9.tree_new_bee_front.dao.UserRegisterDao;
import com.xuetang9.tree_new_bee_front.domain.entity.User;
import com.xuetang9.tree_new_bee_front.service.UserRegisterService;
import lombok.Data;

@Data
public class UserRegisterServiceImpl implements UserRegisterService {

    private UserRegisterDao userRegisterDao;

    @Override
    public boolean selectAccount(String userName) {
        return userRegisterDao.selectAccount(userName) > 0;
    }

    @Override
    public boolean insertOne(User user) {
        return userRegisterDao.inserOne(user) > 0;
    }
}
