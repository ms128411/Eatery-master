package com.xuetang9.tree_new_bee_front.service;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee_front.domain.query.NewsHomeQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.NewsHomeVo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/10:46
 * @Description:
 */
public interface NewsHomeService {
    PageResult<NewsHomeVo> getList(NewsHomeQuery homeQuery);

    NewsHomeVo getCount(NewsHomeQuery homeQuery);

    List<NewsHomeVo> getnewList( NewsHomeQuery homeQuery);
}
