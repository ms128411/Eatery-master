package com.xuetang9.tree_new_bee_front.util.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author 老九学堂
 * @copyright 老九学堂
 */
public interface RowMapper<T> {

    /**
     * 把查询的结果集的一行数据转换为一个对象
     *
     * @param resultSet
     * @return
     * @throws SQLException
     */
    T rowToObject(ResultSet resultSet) throws SQLException;
}
