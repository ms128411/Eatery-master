package com.xuetang9.tree_new_bee_front.util.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @desc： 工具类
 * @Author: luoChen
 * @Date: 2021/7/9 18:18
 */
public class ServletUtils {
	
	/**
	 * description: 创建对象映射器
	 */
	private static ObjectMapper objectMapper = new ObjectMapper();
	
	private ServletUtils() {
	}
	
	public static String getParameter(HttpServletRequest request, String name) {
		String value = request.getParameter(name);
		return value == null ? "" : value;
	}
	
	public static String getParameter(HttpServletRequest request, String name, String defaultValue) {
		String value = getParameter(request, name);
		return value.isEmpty() ? defaultValue : value;
	}
	
	public static int getParameter(HttpServletRequest request, String name, int defaultValue) {
		String value = getParameter(request, name);
		return value.isEmpty() ? defaultValue : Integer.parseInt(value);
	}
	
	public static int[] getParameterIntegers(HttpServletRequest request, String name) {
		String[] values = request.getParameterValues(name);
		if (values == null) {
			return null;
		}
		List<Integer> nums = new ArrayList<>();
		for (String value : values) {
			if (value.isEmpty()) {
				continue;
			}
			nums.add(Integer.parseInt(value));
		}
		int[] numbers = new int[nums.size()];
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = nums.get(i);
		}
		return numbers;
	}
	
	public static Integer getParameterInteger(HttpServletRequest request, String name) {
		String value = getParameter(request, name);
		return value.isEmpty() ? null : Integer.parseInt(value);
	}
	
	public static Date getParameterDate(HttpServletRequest request, String name) {
		String value = getParameter(request,name);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date = format.parse(value);
			return value == null ? null : date;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Date getParameterDates(HttpServletRequest request, String name) {
		String value = getParameter(request,name);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date date = format.parse(value);
			return value == null ? null : date;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static void writeJsonObject(HttpServletResponse response, Object jsonObject) throws IOException {
		// 设置响应的JSON格式
		response.setHeader("Content-Type", "application/json;charset=utf-8");
		// 将对象转换为JSON格式的字符串
		String jsonStr = objectMapper.writeValueAsString(jsonObject);
		// 把数据响应给前端
		response.getWriter().write(jsonStr);
	}
}
