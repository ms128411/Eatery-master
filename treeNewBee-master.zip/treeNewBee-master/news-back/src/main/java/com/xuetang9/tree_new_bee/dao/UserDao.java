package com.xuetang9.tree_new_bee.dao;

import com.xuetang9.tree_new_bee.domain.entity.Manage;


/**
 * @author ZhangChuanWei
 */
public interface UserDao {
    /**
     * 查询数据库中用户登录账号和密码的方法
     * @param condition
     * @return
     */
    Manage selectOne(Manage condition);
}
