package com.xuetang9.tree_new_bee_front.util.servlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc： 传输数据的格式
 * @Author: luoChen
 * @Date: 2021/7/9 18:13
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JsonResult<T> {
	/**
	 * 状态信息
	 */
	private Integer status;
	/**
	 * 用来标明业务逻辑错误：A0001
	 */
	private String code;
	/**
	 * 响应的提示信息：电量不足
	 */
	private String message;
	/**
	 * 响应的数据
	 */
	private T data;
	/**
	 * 错误数据
	 */
	private Object error;
}
