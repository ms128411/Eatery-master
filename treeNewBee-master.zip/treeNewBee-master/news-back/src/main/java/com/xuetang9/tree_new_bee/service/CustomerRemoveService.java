package com.xuetang9.tree_new_bee.service;

public interface CustomerRemoveService {
    boolean removeOne(int id);
}
