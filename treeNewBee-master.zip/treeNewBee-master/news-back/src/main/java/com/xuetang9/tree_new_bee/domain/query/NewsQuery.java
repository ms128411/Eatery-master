package com.xuetang9.tree_new_bee.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/23/11:05
 * @Description: 新闻请求
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsQuery {
    private Integer id;
    private String title;
    private Integer type;
    private Integer djs;  //点击数
    private String publicTime;
    private String introduction;
    private String content;  // 简介
    private String zz;  // 作者
    private int pageIndex;
    private int pageSize;

    //请求列表的构造方法
    public NewsQuery(String title, int pageIndex, int pageSize) {
        this.title = title;
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
    }


    //添加请求的构造方法
    public NewsQuery(String title, String zz, String introduction, Integer type, String content,String publicTime) {
        this.title = title;
        this.type = type;
        this.introduction = introduction;
        this.content = content;
        this.zz = zz;
        this.publicTime = publicTime;
    }

    public NewsQuery(Integer id, String title, Integer type, String introduction, String content, String zz) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.introduction = introduction;
        this.content = content;
        this.zz = zz;
    }
}
