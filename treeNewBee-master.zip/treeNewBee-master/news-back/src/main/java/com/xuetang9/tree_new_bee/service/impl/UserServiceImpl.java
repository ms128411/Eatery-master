package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.UserDao;
import com.xuetang9.tree_new_bee.domain.entity.Manage;
import com.xuetang9.tree_new_bee.domain.query.LoginQuery;
import com.xuetang9.tree_new_bee.domain.vo.LoginVo;
import com.xuetang9.tree_new_bee.service.UserService;
import lombok.Data;

/**
 * @desc 登录的service实现类
 * @author ZhangChuanWei
 */
@Data
public class UserServiceImpl implements UserService {

    private LoginVo loginVo;
    private Manage manage;
    private UserDao userDao;
    @Override
    public LoginVo login(LoginQuery loginQuery) {
        //1.把页面需要的数据转换为数据库操作的参数
        manage.setUserName(loginQuery.getUserName());
        manage.setPassWord(loginQuery.getPassWord());
        //2.调用数据访问层
        Manage loginUser = userDao.selectOne(manage);
        //3.判断返回的结果
        if (loginUser == null){
            return null;
        }
        //4.把数据转换为界面所需的数据
        //LoginVo loginVo = new LoginVo();
        loginVo.setId(loginUser.getId());
        loginVo.setUserName(loginUser.getUserName());
        loginVo.setPassWord(loginUser.getPassWord());
        return loginVo;
    }
}
