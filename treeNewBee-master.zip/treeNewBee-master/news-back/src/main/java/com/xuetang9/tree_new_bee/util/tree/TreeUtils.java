package com.xuetang9.tree_new_bee.util.tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 用来定义一个处理树形结构数据转换的工具
 *
 * @author 老九学堂
 * @copyright 老九学堂
 */
public class TreeUtils {
	
	private TreeUtils() {
	}
	
	/**
	 * 将指定的集合数据转换为对应的树形结构数据
	 *
	 * @param list       需要转换的集合数据
	 * @param nodeMapper 集合中每个数据与树形节点数据的转换器
	 * @param rootId     顶级根节点的id编号
	 * @param <T>        集合中元素的数据类型
	 * @param <ID>       集合中元素id属性的数据类型
	 * @return 返回构建成功的树结构数据
	 */
	public static <T, ID> List<TreeNode<T, ID>> listToTree(List<T> list, NodeMapper<T, ID> nodeMapper, ID rootId) {
		// 循环遍历集合中数据，将集合中的每一个元素转换为树形节点，并添加到一个新的集合中
		List<TreeNode<T, ID>> nodes = list.stream().map(nodeMapper::mapNode).collect(Collectors.toList());
		// 构建一个集合用于保存经过处理的树形数据
		List<TreeNode<T, ID>> tree = new ArrayList<>();
		// 循环遍历根节点
		for (TreeNode<T, ID> node : nodes) {
			if (rootId.equals(node.getPid())) {
				// 设置父节点的深度
				node.setDepth(0);
				// 添加节点到树中
				tree.add(node);
				// 找到父节点下对应的子节点
				findChildNodes(node, nodes);
			}
		}
		// 返回树形节点的组装数据
		return tree;
	}
	
	/**
	 * 递归处理节点的子节点
	 *
	 * @param parentNode 需要进行查找子节点操作的父节点
	 * @param nodes      子节点数据所在的集合
	 * @param <T>        集合中元素的数据类型
	 * @param <ID>       集合中元素id属性的数据类型
	 */
	private static <T, ID> void findChildNodes(TreeNode<T, ID> parentNode, List<TreeNode<T, ID>> nodes) {
		// 循环遍历节点
		for (TreeNode<T, ID> childNode : nodes) {
			// 判断当前节点是否是parentNode的子节点
			if (childNode.getPid().equals(parentNode.getId())) {
				// 判断父级节点的子节点集合是否为空
				if (parentNode.getChildren() == null) {
					parentNode.setChildren(new ArrayList<>());
				}
				// 设置子节点的深度
				childNode.setDepth(parentNode.getDepth() + 1);
				// 添加子节点到集合中
				parentNode.getChildren().add(childNode);
				// 查找子节点的子节点
				findChildNodes(childNode, nodes);
			}
		}
	}
	
	/**
	 * 将指定的集合数据转换为对应的树形结构数据
	 *
	 * @param list       需要转换的集合数据
	 * @param nodeMapper 集合中每个数据与树形节点数据的转换器
	 * @param rootId     顶级根节点的id编号
	 * @param <T>        集合中元素的数据类型
	 * @param <ID>       集合中元素id属性的数据类型
	 * @return 返回构建成功的树结构数据
	 */
	public static <T, ID> List<TreeNode<T, ID>> listToTreeByCollection(List<T> list, NodeMapper<T, ID> nodeMapper, ID rootId) {
		// 构建一个集合用于保存经过处理的树形数据
		List<TreeNode<T, ID>> tree = new ArrayList<>();
		// 将集合中的数据转换为树节点数据
		List<TreeNode<T, ID>> nodes = list.stream().map(nodeMapper::mapNode).collect(Collectors.toList());
		// 循环遍历节点
		nodes.forEach(node -> {
//            // 查找到根节点
//            if (node.getPid().equals(rootId)) {
//                // 将根节点添加到树节点集合中
//                tree.add(node);
//            }
//            // 查找到当前节点的子节点
//            List<TreeNode<T, ID>> childNodes = nodes.stream().filter(child -> child.getPid().equals(node.getId())).collect(Collectors.toList());
//            // 如果存在就添加到子节点中
//            if (!childNodes.isEmpty()) {
//                if (node.getChildren() == null) {
//                    node.setChildren(new ArrayList<>());
//                }
//                // 添加子节点到当前子节点的集合中
//                node.getChildren().addAll(childNodes);
//            }
			// 查找当前节点的父节点
			if (node.getPid().equals(rootId)) {
				// 将根节点添加到树节点集合中
				tree.add(node);
			} else {
				TreeNode<T, ID> parentNode = nodes.stream().filter(parent -> node.getPid().equals(parent.getId())).findFirst().orElse(null);
				if (parentNode != null) {
					if (parentNode.getChildren() == null) {
						parentNode.setChildren(new ArrayList<>());
					}
					parentNode.getChildren().add(node);
				}
			}
		});
		// 返回数据类型
		return tree;
	}
	
	
	/**
	 * 将指定的集合数据转换为对应的树形结构数据
	 *
	 * @param list       需要转换的集合数据
	 * @param nodeMapper 集合中每个数据与树形节点数据的转换器
	 * @param rootId     顶级根节点的id编号
	 * @param <T>        集合中元素的数据类型
	 * @param <ID>       集合中元素id属性的数据类型
	 * @return 返回构建成功的树结构数据
	 */
	public static <T, ID> List<TreeNode<T, ID>> listToTreeByMap(List<T> list, NodeMapper<T, ID> nodeMapper, ID rootId) {
		// 构建一个集合用于保存经过处理的树形数据
		List<TreeNode<T, ID>> tree = new ArrayList<>();
		// 把集合数据转换为一个以ID为键,TreeNode为值的Map集合
		Map<ID, TreeNode<T, ID>> nodeMap = list.stream().map(nodeMapper::mapNode).collect(Collectors.toMap(TreeNode::getId, node -> node));
		// 循环map集合找到当前节点的父级节点，并添加
		nodeMap.forEach((key, node) -> {
			// 找到顶级节点
			if (node.getPid().equals(rootId)) {
				// 将节点添加到树节点集合中
				tree.add(node);
			} else if (nodeMap.containsKey(node.getPid())) {
				// 获取父级节点
				TreeNode<T, ID> parent = nodeMap.get(node.getPid());
				// 判断父级节点的子节点集合是否为空
				if (parent.getChildren() == null) {
					parent.setChildren(new ArrayList<>());
				}
				// 添加节点到子节点集合中
				parent.getChildren().add(node);
			}
		});
		// 后处理树形数据的属性
		afterProperties(tree);
		return tree;
	}
	
	/**
	 * description:后处理树形数据的属性
	 *
	 * @param tree
	 * @return java.util.List<com.xuetang9.web.forum_admin_back.util.tree.TreeNode < T, ID>>
	 */
	private static <T, ID> List<TreeNode<T, ID>> afterProperties(List<TreeNode<T, ID>> tree) {
		// 定义一个队列，用来作为树形节点的遍历
		LinkedList<TreeNode<T, ID>> linkedList = new LinkedList<>();
		// 将根节点添加到队列中
		linkedList.addAll(tree);
		// 设置根节点深度
		tree.forEach(node -> {
			node.setDepth(0);
		});
		// 依次遍历队列中的树节点的结构
		while (!linkedList.isEmpty()) {
			// 取出队列的第一个
			TreeNode<T, ID> node = linkedList.removeFirst();
			// 遍历节点
			if (node.getChildren() == null) {
				node.setLeaf(true);
			} else {
				// 将子节点添加到队列的末尾
				linkedList.addAll(node.getChildren());
				// 设置不是叶子节点
				node.setLeaf(false);
				// 设置子节点深度
				node.getChildren().forEach(child -> {
					child.setDepth(node.getDepth() + 1);
				});
			}
		}
		return tree;
	}
	
}
