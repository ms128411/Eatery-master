package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.query.CommentDeleteQuery;

/**
 * 评论删除的Service
 * @author ZhangChuanWei
 */
public interface CommentDeleteService {

    /**
     * 通过id删除
     * @param commentDeleteQuery
     * @return
     */
    int deleteById(CommentDeleteQuery commentDeleteQuery);
}
