package com.xuetang9.tree_new_bee_front.service;

import com.xuetang9.tree_new_bee_front.domain.entity.User;

public interface UserRegisterService {
    boolean selectAccount(String userName);

    boolean insertOne(User user);
}
