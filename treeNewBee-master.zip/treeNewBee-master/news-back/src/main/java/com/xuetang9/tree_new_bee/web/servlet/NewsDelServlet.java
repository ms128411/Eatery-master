package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.service.NewsService;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/25/12:05
 * @Description: 新闻删除
 */
@WebServlet("/newsDel")
public class NewsDelServlet extends HttpServlet {
    @Autowired
    private NewsService newsService;

    @Override
    public void init() throws ServletException {
        //让Spring IoC容器自动把Servlet注入IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult<String> jsonResult = new JsonResult<>();
        Integer id = ServletUtils.getParameterInteger(req, "id");
        Map<String, String> errors = new HashMap<>();
        if (id == null) {
            errors.put("id", "属性为空");
        }

        if (!errors.isEmpty()) {
            jsonResult.setCode("A000088");
            jsonResult.setStatus(200);
            jsonResult.setError(errors);
            jsonResult.setMessage("缺少参数");
            ServletUtils.writeJsonObject(resp, jsonResult);
            return;
        }
        NewsQuery newsQuery = new NewsQuery();
        newsQuery.setId(id);
        if (newsService.newsDel(newsQuery)) {

        }

    }
}
