package com.xuetang9.tree_new_bee.web.servlet;


import com.xuetang9.tree_new_bee.domain.vo.CustomerVo;
import com.xuetang9.tree_new_bee.service.CustomerListService;
import com.xuetang9.tree_new_bee.service.CustomerRemoveService;


import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 删除用户
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@WebServlet("/customer/remove")
public class CustomerRemoveServlet extends HttpServlet {
    @Autowired
    private CustomerRemoveService customerRemoveService;

    private JsonResult json = new JsonResult();
    @Autowired
    private CustomerListService customerListService;


    @Override
    public void init() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
        super.init();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = ServletUtils.getParameter(req, "id", -1);

        //进行用户假删除操作
        boolean yes = customerRemoveService.removeOne(id);
        json.setStatus(200);
        if(yes){
            JsonResult<PageResult<CustomerVo>> jsonResult = new JsonResult<>();
            //收集数据
            String realName = ServletUtils.getParameter(req, "name");
            int pageIndex = ServletUtils.getParameter(req, "pageIndex", 1);
            int pageSize = ServletUtils.getParameter(req, "pageSize", 10);
            //获取总数据量
            int sum = customerListService.selectSum(realName);
            if (sum == 0) {
                return;
            }
            //调用服务层获取分页数据
            PageResult<CustomerVo> pageResult = customerListService.selectAll(realName, pageIndex, pageSize, sum);
            //拼装返回前端的数据
            json.setData(pageResult);
            json.setStatus(200);
            json.setCode("00000");
            json.setMessage("用户删除成功");
            ServletUtils.writeJsonObject(resp, json);

        }else{
            json.setCode("A0001");
            json.setMessage("用户删除失败");
            ServletUtils.writeJsonObject(resp,json);
        }



    }
}
