package com.xuetang9.tree_new_bee.service.impl;
import com.xuetang9.tree_new_bee.dao.NewsDao;
import com.xuetang9.tree_new_bee.domain.entity.News;
import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.service.NewsService;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/23/10：00
 * @Description: 新闻服务层实现类
 */
@Data

public class NewsServiceImpl implements NewsService {

    private NewsDao newsDao;

    @Override
    public PageResult<NewsVo> getNewsList(NewsQuery newsQuery) {
        PageResult<NewsVo> pageResult = new PageResult<>();
        int total = newsDao.getCount(newsQuery);
        if (total > 0) {
            List<NewsVo> list = newsDao.getNewsList(newsQuery);
            pageResult.setRows(list);
        }
        pageResult.setPageIndex(newsQuery.getPageIndex());
        pageResult.setPageSize(newsQuery.getPageSize());
        pageResult.setTotal(total);
        return pageResult;
    }

    @Override
    public boolean newsAdd(NewsQuery nQ) {
        //判断必填项是否为空
        if (StringUtils.isNullOrWhitespace(nQ.getTitle())) {
            return false;
        }
        if (StringUtils.isNullOrWhitespace(nQ.getZz())) {
            return false;
        }
        if (nQ.getType() ==null) {
            return false;
        }
        if (StringUtils.isNullOrWhitespace(nQ.getContent())) {
            return false;
        }
        News news = new News(nQ.getTitle(), nQ.getZz(), nQ.getIntroduction(), nQ.getType(), nQ.getContent());
        news.setPublicTime(nQ.getPublicTime());
        return newsDao.newsAdd(news) > 0 ? true : false;
    }

    @Override
    public boolean newsDel(NewsQuery newsQuery) {
        return newsDao.newsDel(newsQuery) > 0 ? true : false;
    }

    @Override
    public boolean newsUpdata(NewsQuery newsQuery) {
        News news = new News();
        news.setId(newsQuery.getId());
        news.setTitle(newsQuery.getTitle());
        news.setType(newsQuery.getType());
        news.setIntroduction(newsQuery.getIntroduction());
        news.setContent(newsQuery.getContent());
        news.setZz(newsQuery.getZz());
        return newsDao.newsUpdata(news) > 0 ? true : false;
    }
}
