package com.xuetang9.tree_new_bee.domain.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 置顶评论要查询的数据
 * @author ZhangChuanWei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentRecommendQuery {
    private Integer id;
    private Integer zd;
}
