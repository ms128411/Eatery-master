package com.xuetang9.tree_new_bee.util.tree;

/**
 * 定义一个将对象转换为树形节点数据的接口
 *
 * @author 老九学堂
 * @copyright 老九学堂
 */
public interface NodeMapper<T, ID> {

    /**
     * 把传入的参数对象转换为一个树形节点对象
     *
     * @param item
     * @return
     */
    TreeNode<T, ID> mapNode(T item);

}
