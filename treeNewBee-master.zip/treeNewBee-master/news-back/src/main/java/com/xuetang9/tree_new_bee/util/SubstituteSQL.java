package com.xuetang9.tree_new_bee.util;

public class SubstituteSQL {
    public static String substitute(String a){
        String b = "";
        for (int i = 0; i < a.length(); i++) {
            char ch = a.charAt(i);
            if(Character.isUpperCase(ch)){
                b += "_";
                b += Character.toLowerCase(ch);
            }else{
                b += ch;
            }

        }
        return b;
    }

}
