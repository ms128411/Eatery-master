package com.xuetang9.tree_new_bee.dao.impl;

import com.xuetang9.tree_new_bee.dao.CustomerRemoveDao;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * 用户删除
 * 作者：周威
 * 时间：2021年7月26日19点52分
 */
@Data
@Repository
public class CustomerRemoveDaoImpl implements CustomerRemoveDao {

    @Autowired
    private JdbcTemplate jdbc;
    @Override
    public int removeOne(int id) {
        String sql = "update user set display = case display when 0 then 1 end where id = ?";
        return jdbc.executeUpdate(sql, id);

    }
}
