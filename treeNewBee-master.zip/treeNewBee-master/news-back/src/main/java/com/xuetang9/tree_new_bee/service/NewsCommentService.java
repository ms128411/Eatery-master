package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.query.NewsCommentQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsCommentVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;

/**
 * 新闻评论的service
 * @author ZhangChuanWei
 */
public interface NewsCommentService {
    /**
     * 根据条件查询数据
     * @param newCommentQuery
     * @return
     */
    PageResult<NewsCommentVo> listByPageAndCondition(NewsCommentQuery newCommentQuery);


    /**
     * 获取数据的总条数
     * @return
     */
    int queryCount(int id);

}
