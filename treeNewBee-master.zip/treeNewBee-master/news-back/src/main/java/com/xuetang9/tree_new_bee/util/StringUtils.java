package com.xuetang9.tree_new_bee.util;

/**
 * 字符串工具类
 *
 * @author 老九学堂
 * @copyright 老九学堂
 */
public class StringUtils {

    private StringUtils() {
    }

    /**
     * 判断字符串是否为null或者空白
     * @param value
     * @return
     */
    public static boolean isNullOrWhitespace(String value) {
        return value == null || value.trim().isEmpty();
    }

}
