package com.xuetang9.tree_new_bee_front.service.impl;

import com.xuetang9.tree_new_bee_front.dao.FrontUserDao;
import com.xuetang9.tree_new_bee_front.domain.entity.User;
import com.xuetang9.tree_new_bee_front.domain.query.FrontLoginQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.FrontLoginVo;
import com.xuetang9.tree_new_bee_front.service.FrontUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @desc： 登录业务实现层
 * @Author: luoChen
 * @Date: 2021/7/27 15:25
 */
@Service
public class FrontUserServiceImpl implements FrontUserService {
	
	@Autowired
	private FrontUserDao frontUserDao;
	//@Autowired
	private User condition = new User();
	@Autowired
	private FrontLoginVo frontLoginVo;
	
	@Override
	public FrontLoginVo login(FrontLoginQuery frontLoginQuery) {
		// 把登录的参数，构建成数据库操作所需的参数
		condition.setUserName(frontLoginQuery.getUserName());
		condition.setPassWord(frontLoginQuery.getPassWord());
		// 调用数据访问层
		User loginUser = frontUserDao.selectOne(condition);
		// 判断结果
		if (loginUser == null) {
			return null;
		}
		// 把数据转换为界面所需的数据
		frontLoginVo.setId(loginUser.getId());
		frontLoginVo.setUserName(loginUser.getUserName());
		frontLoginVo.setPassWord(loginUser.getPassWord());
		frontLoginVo.setPhone(loginUser.getPhone());
		frontLoginVo.setRealName(loginUser.getRealName());
		frontLoginVo.setEmail(loginUser.getEmail());
		return frontLoginVo;
	}
}
