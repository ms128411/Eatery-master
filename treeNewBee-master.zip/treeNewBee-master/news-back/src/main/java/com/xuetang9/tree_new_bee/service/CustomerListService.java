package com.xuetang9.tree_new_bee.service;

import com.xuetang9.tree_new_bee.domain.vo.CustomerVo;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;

public interface CustomerListService {
    /**
     * 根据条件获取用户数据总数
      * @param realName
     * @return
     */
    int selectSum(String realName);

    /**
     * 根据条件获取分页数据
     * @param realName
     * @param pageIndex
     * @param pageSize
     * @param sum
     * @return
     */
    PageResult<CustomerVo> selectAll(String realName, int pageIndex, int pageSize,int sum);


}
