package com.xuetang9.tree_new_bee.util.servlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc： 分页数据的格式
 * @Author: luoChen
 * @Date: 2021/7/13 16:33
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageResult<T> {
	private List<T> rows;
	private Integer pageIndex;
	private Integer pageSize;
	private Integer total;
}
