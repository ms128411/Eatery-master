package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CustomerListDao;
import com.xuetang9.tree_new_bee.domain.vo.CustomerVo;
import com.xuetang9.tree_new_bee.service.CustomerListService;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import lombok.Data;
import org.springframework.stereotype.Service;


/**
 * 用户列表服务层实现类
 * 作者周威
 * 时间：2021年7月26日19点52分
 */

@Data

public class CustomerListServiceImpl implements CustomerListService {

    private CustomerListDao customerListDao;

    @Override
    public int selectSum(String realName) {
        int i = customerListDao.selectSum(realName);
        return i;

    }

    @Override
    public PageResult<CustomerVo> selectAll(String realName, int pageIndex, int pageSize, int sum) {
        return customerListDao.selectAll(realName,pageIndex,pageSize,sum);

    }

}