package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.CommentDeleteDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.entity.Manage;
import com.xuetang9.tree_new_bee.domain.query.CommentDeleteQuery;
import com.xuetang9.tree_new_bee.domain.vo.CommentDeleteVo;
import com.xuetang9.tree_new_bee.service.CommentDeleteService;
import lombok.Data;

/**
 * 删除评论的Service实现类
 * @author ZhangChuanWei
 */
@Data
public class CommentDeleteServiceImpl implements CommentDeleteService {
    private CommentDeleteDao commentDeleteDao;
    private CommentDeleteVo commentDeleteVo;
    @Override
    public int deleteById(CommentDeleteQuery commentDeleteQuery) {
        //把页面数据转换为数据库操作所需的参数
        Comment comment = new Comment();
        comment.setId(commentDeleteQuery.getId());
        //调用dao层方法
        return commentDeleteDao.removeCommentById(comment);
    }
}
