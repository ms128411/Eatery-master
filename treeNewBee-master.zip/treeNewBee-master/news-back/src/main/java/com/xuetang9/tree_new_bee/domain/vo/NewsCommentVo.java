package com.xuetang9.tree_new_bee.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 页面要展示的数据
 * @author ZhangChuanWei
 */
@Data
public class NewsCommentVo implements Serializable {

    private Integer id;
    private String title;

    private String content;

    private String name;

    private Integer zd;
}
