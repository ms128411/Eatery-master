package com.xuetang9.tree_new_bee_front.dao.impl;

import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.util.StringUtils;
import com.xuetang9.tree_new_bee.util.jdbc.JdbcTemplate;
import com.xuetang9.tree_new_bee.util.jdbc.RowMapper;
import com.xuetang9.tree_new_bee_front.dao.NewsHomeDao;
import com.xuetang9.tree_new_bee_front.domain.query.NewsHomeQuery;
import com.xuetang9.tree_new_bee_front.domain.vo.NewsHomeVo;
import lombok.Data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/27/11:00
 * @Description: 前台首页DAO
 */
@Data
public class NewsHomeDaoImpl implements NewsHomeDao {
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<NewsHomeVo> getList(NewsHomeQuery homeQuery) {
        String sql = "SELECT * FROM `news` WHERE 1=1 ";
        List<Object> params = new ArrayList<>();
        if (homeQuery.getType() != null) {
            sql += " and type = ? ";
            params.add(homeQuery.getType());
        }
        if (homeQuery.getPageIndex() != null) {
            sql += " limit ?, ? ";
            params.add((homeQuery.getPageIndex() - 1) * homeQuery.getPageSize());
            params.add(homeQuery.getPageSize());
        }
        RowMapper<NewsHomeVo> rowMapper = new RowMapper<NewsHomeVo>() {
            @Override
            public NewsHomeVo rowToObject(ResultSet rs) throws SQLException {
                NewsHomeVo newsVo = new NewsHomeVo();
                newsVo.setId(rs.getInt("id"));
//                newsVo.setContent(rs.getString("content"));
                newsVo.setCreateTime(rs.getDate("createTime").toString());
                newsVo.setDjs(rs.getInt("djs"));
                newsVo.setIntroduction(rs.getString("introduction"));
                newsVo.setTitle(rs.getString("title"));
                newsVo.setZz(rs.getString("zz"));
                newsVo.setType(rs.getInt("type"));
                return newsVo;
            }
        };
        return jdbcTemplate.executeQuery(sql, rowMapper, params.toArray());
    }

    @Override
    public int getCount(NewsHomeQuery homeQuery) {
        String sql = " select count(*) from `news` where 1=1 ";
        List<Object> params = new ArrayList<>();
        if (homeQuery.getType()!=null) {
            sql += " and type = ? ";
            params.add(homeQuery.getType());
        }
        Object value = jdbcTemplate.executeQueryUnique(sql,params.toArray());
        return Integer.parseInt(value.toString());
    }

    @Override
    public NewsHomeVo getContent(NewsHomeQuery homeQuery) {
        String sql = "SELECT * FROM `news` WHERE id = ? ";
        RowMapper<NewsHomeVo> rowMapper = new RowMapper<NewsHomeVo>() {
            @Override
            public NewsHomeVo rowToObject(ResultSet rs) throws SQLException {
                NewsHomeVo newsVo = new NewsHomeVo();
                newsVo.setId(rs.getInt("id"));
                newsVo.setContent(rs.getString("content"));
                newsVo.setCreateTime(rs.getDate("createTime").toString());
                newsVo.setDjs(rs.getInt("djs"));
                newsVo.setIntroduction(rs.getString("introduction"));
                newsVo.setTitle(rs.getString("title"));
                newsVo.setZz(rs.getString("zz"));
                newsVo.setType(rs.getInt("type"));
                return newsVo;
            }
        };
        return jdbcTemplate.executeQueryOne(sql, rowMapper, homeQuery.getId());
    }

    @Override
    public List<NewsHomeVo> getnewList(NewsHomeQuery homeQuery) {
        String sql = "SELECT id,title FROM `news` WHERE 1=1";
        List<Object> params = new ArrayList<>();
        if (homeQuery.getType() != null) {
            sql += " and type = ? ";
            params.add(homeQuery.getType());
        }

        sql += "  ORDER BY createTime DESC LIMIT 0,5";
        RowMapper<NewsHomeVo> rowMapper = new RowMapper<NewsHomeVo>() {
            @Override
            public NewsHomeVo rowToObject(ResultSet rs) throws SQLException {
                NewsHomeVo newsVo = new NewsHomeVo();
                newsVo.setId(rs.getInt("id"));
                newsVo.setTitle(rs.getString("title"));
                return newsVo;
            }
        };
        return jdbcTemplate.executeQuery(sql, rowMapper, params.toArray());
    }
}
