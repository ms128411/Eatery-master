package com.xuetang9.tree_new_bee.service.impl;

import com.xuetang9.tree_new_bee.dao.NewsCommentDao;
import com.xuetang9.tree_new_bee.domain.entity.Comment;
import com.xuetang9.tree_new_bee.domain.query.NewsCommentQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsCommentVo;
import com.xuetang9.tree_new_bee.service.NewsCommentService;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ZhangChuanWei
 */
@Data
public class NewsCommentServiceImpl implements NewsCommentService {
    private NewsCommentDao newsCommentDao;


    //调用数据访问层的对象
    /**
     * 获取数据的总条数
     * @return
     */
    @Override
    public int queryCount(int id) {
        int total = newsCommentDao.selectCount(id);
        return total;
    }
    @Override
    public PageResult<NewsCommentVo> listByPageAndCondition(NewsCommentQuery newCommentQuery) {

        PageResult<NewsCommentVo> pageResult = new PageResult<>();
        pageResult = newsCommentDao.selectList(newCommentQuery.getId(),newCommentQuery.getPageIndex(),newCommentQuery.getPageSize(),newCommentQuery.getTotal());
        return pageResult;
    }


}
