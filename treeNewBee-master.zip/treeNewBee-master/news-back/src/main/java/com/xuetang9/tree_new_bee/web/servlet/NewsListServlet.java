package com.xuetang9.tree_new_bee.web.servlet;

import com.xuetang9.tree_new_bee.domain.query.NewsQuery;
import com.xuetang9.tree_new_bee.domain.vo.NewsVo;
import com.xuetang9.tree_new_bee.service.NewsService;
import com.xuetang9.tree_new_bee.service.impl.NewsServiceImpl;
import com.xuetang9.tree_new_bee.util.servlet.JsonResult;
import com.xuetang9.tree_new_bee.util.servlet.PageResult;
import com.xuetang9.tree_new_bee.util.servlet.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 崔超凡
 * @Date: 2021/07/23/10：00
 * @Description: 新闻列表Servlet
 */
@WebServlet("/newsList")
public class NewsListServlet extends HttpServlet {
    @Autowired
    private NewsService newsService;

    @Override
    public void init() throws ServletException {
        //让Spring IoC容器自动把Servlet注入IoC容器中
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,getServletContext());
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JsonResult<PageResult<NewsVo>> jsonResult = new JsonResult<>();
        int pageIndex = ServletUtils.getParameter(req, "pageIndex", 1);
        int pageSize = ServletUtils.getParameter(req, "pageSize", 10);
        String title = ServletUtils.getParameter(req, "title");
        NewsQuery newsQuery = new NewsQuery(title, pageIndex, pageSize);
        PageResult<NewsVo> pageResult = newsService.getNewsList(newsQuery);
        jsonResult.setData(pageResult);
        jsonResult.setStatus(200);

        ServletUtils.writeJsonObject(resp, jsonResult);
    }
}
