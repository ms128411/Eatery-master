package net.togogo.domain;

import lombok.Data;

@Data
public class Type {

    private int typeID;//新闻类别编号
    private String newsType;//新闻类别名称

}
